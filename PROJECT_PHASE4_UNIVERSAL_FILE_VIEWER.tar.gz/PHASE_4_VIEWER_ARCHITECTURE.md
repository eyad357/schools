# PHASE 4 — Viewer Architecture

Companion to `PHASE_4_VIEWER_AUDIT.md` (the investigation this document's
decisions are based on) and `PHASE_4_CHANGE_MANIFEST.md` (the exact
diff). This document describes the architecture **after** Phase 4 —
which, per the audit's risk assessment, is the existing architecture,
evolved, not replaced.

---

## 1. Current Architecture

See `PHASE_4_VIEWER_AUDIT.md` §1–§13 for the full investigation. In one
sentence: a single shared shell (`ensureDOM()`, built once) with one
central dispatch table (`renderersByEngine`, keyed by
`FileSupportPolicy`'s `preview.engine`) routing to 8 format-specific
render functions, each of which only builds its own toolbar controls and
content area using shared helpers.

## 2. Problems Found

Five, all listed with full detail in `PHASE_4_VIEWER_AUDIT.md` §14: two
lifecycle-cleanup gaps (PDF `IntersectionObserver`s, image pan
listeners), one functional bug (word/text zoom no-op), one real-file-
driven classification gap (`.ppsx` missing), one harmless dead-code
leftover. **All five fixed this phase** — see
`PHASE_4_CHANGE_MANIFEST.md`.

## 3. Target Architecture

```
                         Evidence
                            |
                            v
                    FileSupportPolicy
                 (classification + capability
                  model — getPolicy() /
                  getViewerCapabilities())
                            |
                            v
                  renderersByEngine table
                  (app/js/viewer.js — the
                   ViewerResolver's actual
                   decision point, unchanged
                   mechanism from before Phase 4)
                            |
              +-------------+-------------+
              |                           |
      Shared Viewer Shell           Format Render Function
      (ensureDOM, open/close,        (renderPdf, renderWordDocx,
       cleanupPrevious, toolbar       renderExcel, renderPptx,
       helpers, search engine,        renderImage, renderMedia,
       info panel, loading/error      renderText, renderUnsupported-
       states, keyboard handling)     Office / renderFallback)
```

This is the same diagram the brief itself proposes (`Evidence →
FileSupportPolicy → ViewerResolver → ViewerDescriptor → {Shell, Format
Engine}`), mapped onto names that already exist in this codebase rather
than inventing new ones — per the brief's own instruction: *"Do not
blindly copy this structure if the existing project uses a better
architecture... the important concept is ONE CENTRAL DECISION."* The one
central decision already exists (`getPolicy().preview.engine` →
`renderersByEngine`); Phase 4 adds the capability half of the
"ViewerDescriptor" concept as data (§6) without duplicating or replacing
the decision point itself.

## 4. Viewer Shell

Unchanged in this phase except for the two lifecycle-cleanup fixes
inside `cleanupPrevious()`. Owns: DOM scaffold (built once), toolbar
mount point + helper functions (`addToolBtn`/`addSep`/
`addZoomControls`/`addSearchToggle`), generic search engine (text-node
walking + highlighting, used by word/excel/text/pptx), info panel
(`buildInfoPanel()`/`setInfoExtra()`), loading/error states
(`showLoading`/`showError`), fullscreen toggle, download link, keyboard
handling, and now (this phase) the complete lifecycle-cleanup contract
(§5).

## 5. Viewer Resolver

`FileSupportPolicy.getPolicy(filename)` → `.preview.engine` →
`renderersByEngine[engine]`. This is the resolver — already centralized
before this phase (confirmed in the audit), unchanged in mechanism.
What Phase 4 adds is a second, read-only query surface,
`FileSupportPolicy.getViewerCapabilities(filename)`, which returns the
capability flags for whatever engine `getPolicy()` would resolve to —
giving any future caller (a toolbar-configuration screen, a settings
page describing what's viewable, a different UI surface entirely) a way
to ask "what can this format's viewer do?" without needing to know
`viewer.js`'s internals or duplicate its render functions' toolbar-
building logic.

## 6. Capability Model

`FileSupportPolicy.VIEWER_CAPABILITIES_BY_ENGINE`, keyed by the exact
same 8 engine-name strings `renderersByEngine` already uses:

```js
{
  'pdfjs':               { zoom, fitWidth, fitPage, pageNavigation, thumbnails, rotate, search, print, fullscreen },
  'mammoth':              { zoom, search, fullscreen },
  'sheetjs':              { sheetNavigation, search, fullscreen },
  'pptx-text-extract':    { slideNavigation, search, fullscreen },
  'native-image':         { zoom, pan, rotate, gallery, fullscreen },
  'native-media-video':   { playback, seek, volume, playbackSpeed, fullscreen },
  'native-media-audio':   { playback, seek, volume, playbackSpeed },
  'plaintext':            { zoom, search, fullscreen },
}
```

**Every flag reflects verified, existing behavior** — not an
aspirational or planned capability. This was checked two ways: (1) by
reading each render function directly during the audit, and (2) by a
permanent, automated, static regression guard
(`scripts/viewer-lifecycle-test.js`) that re-derives, from `viewer.js`'s
actual source, which toolbar-building calls (`addZoomControls`,
`addSearchToggle`, etc.) each render function makes, and fails if any
capability entry claims something the corresponding function doesn't
actually build — the exact same class of "table drifts from reality"
problem Phase 0 already fixed once for the old per-format extension
tables, now guarded against for this new table from day one. This is
also *why* excel/pptx explicitly do **not** claim `zoom: true` — neither
`renderExcel()` nor `renderPptx()` calls `addZoomControls()` today, so
claiming otherwise would be exactly the "fake support" the brief
prohibits.

## 7. Format Engines

Unchanged in rendering strategy for all 8 (per the brief's explicit "do
not fix PDF/PowerPoint rendering" instruction — this phase touched
*lifecycle* and *dispatch* code, never a rendering algorithm). Two
received real bug fixes (word/text zoom dispatch — a wiring bug, not a
rendering-fidelity change) and one received a new, correctly-classified
extension (`.ppsx`, routed to the *existing*, unmodified PPTX engine).

## 8. Shared Toolbar

Already one shared system before this phase (`addToolBtn`/`addSep`/
`addZoomControls`/`addSearchToggle`, all defined once, called by
whichever render functions need them) — confirmed during the audit, not
rebuilt. No format duplicates toolbar markup; every button in every
format's toolbar is built through these same four helper functions.

## 9. File Lifecycle

```
Viewer.open(code, file)
  → ensureDOM()                         [idempotent — builds shell once]
  → cleanupPrevious()                   [tears down whatever was open —
                                          NOW COMPLETE: pdfDoc destroyed,
                                          object URLs revoked, PDF
                                          observers disconnected (NEW),
                                          image pan listeners removed
                                          (NEW), media element stopped,
                                          any format's own mediaCleanup
                                          callback run]
  → freshState()                        [new, empty state object —
                                          nothing carries over between files]
  → resolve category/policy/engine
  → build shell chrome for the new file [icon, filename, subtitle,
                                          download link, info panel]
  → dispatch to the resolved render function
Viewer.close()
  → hide overlay, exit fullscreen if active
  → cleanupPrevious()                   [same complete teardown as above]
```

This already matches the brief's requested `create → initialize → load →
ready → interact → cleanup → destroy` lifecycle — `open()` is
create+initialize+load, the render function reaching a ready/error state
is ready, user interaction happens via the toolbar/shell, and
`cleanupPrevious()` (now complete) is cleanup, called on every
close *and* every subsequent open. There's no separate `destroy` step
because the shell is deliberately kept alive and reused (`ensureDOM()`'s
"built once, reused" comment, unchanged) rather than torn down and
rebuilt per file — a reasonable choice given a single-window desktop
app, cheaper than reconstructing the entire DOM scaffold on every open.

## 10. Error Model

Two shared states — `showLoading(msg)` / `showError(title, sub)` — used
identically by every one of the 8 render functions. No format shows a
raw JavaScript error or a blank panel; every failure path (fetch
failure, corrupt file, unsupported/missing engine) routes through
`showError()`. PDF specifically distinguishes `friendlyTitle`/
`friendlyDetail` from `PDFEngine`'s own error classification (unchanged,
pre-existing) so the user never sees a raw pdf.js/worker exception.

## 11. Security Boundary

Unchanged and re-verified — see `PHASE_4_VIEWER_AUDIT.md` §16 for the
full checklist. No new security surface was introduced; the two
lifecycle fixes are resource-cleanup corrections, not boundary changes.

## 12. Conversion Strategy

**None exists, and none was added.** Every format renders client-side
from bundled libraries (pdf.js, mammoth.js, SheetJS, JSZip) or native
browser elements (`<img>`, `<video>`, `<audio>`) — there is no
server-side conversion step (no LibreOffice-headless, no
PDF-generation-from-Office pipeline) anywhere in this application, before
or after this phase. `FILE-SUPPORT-ARCHITECTURE-REPORT.md`'s existing
proposal for a future server-side-conversion phase (to close the
DOC/PPT/RTF/ODT/ODS/ODP no-preview gap) remains exactly that — a
documented future recommendation, not implemented here, per the brief's
explicit "DO NOT IMPLEMENT OFFICE PREVIEW" instruction for this phase.

## 13. Cache Strategy

**Not applicable** — with no conversion pipeline, there is nothing to
cache. Every render function fetches the original file's bytes directly
(`fetchBytes()`/`state.url`) on every open; nothing is written to disk
by the viewer at any point. This section of the brief's requested
architecture doc is included for completeness, not because this phase
needed to design a cache.

## 14. Cleanup Strategy

See §9 above (`cleanupPrevious()`) for the complete, now-verified-
complete resource-cleanup contract: PDF document destruction, PDF
observer disconnection (new), object URL revocation, media element
stop/detach, format-specific `mediaCleanup` callbacks (the video
scrub-preview's shadow element), and image pan listener removal (new).
Every module-level mutable resource in `viewer.js` was cross-checked
against `cleanupPrevious()` during the audit to confirm nothing else is
left dangling — the full list (`state`, `dom`, `pdfObserver`,
`pdfPageTracker`, `imgPanMove`, `imgPanEnd`, `lastPdfPage`) has exactly
one entry, `lastPdfPage`, that is *deliberately* not cleared (a Map of
remembered page numbers per file for the session's duration — documented
in its own comment as an intentional, bounded, session-only convenience
feature, not a leak: it's keyed by `code/filename` so it never grows
unboundedly relative to the number of distinct files actually opened in
one session, and is discarded entirely on app restart).

## 15. Performance Findings

**Not independently re-measured in this phase.** This sandbox has no
display server (the same limitation documented in every prior phase's
performance sections) — actually opening a real PDF/PPTX/DOCX/video file
in a real Electron window and measuring render time or memory was not
possible here. What Phase 4 *could* and did verify without a display:
that the lazy, `IntersectionObserver`-driven PDF page-rendering strategy
(only rasterizing pages near the viewport, confirmed unchanged in the
audit) is still architecturally intact, and that the two lifecycle leaks
found (§2) would, if left unfixed, have caused exactly the kind of
"increasing memory across file switches" symptom the brief's "Memory /
Cleanup" section describes — their fix directly addresses that concern,
even though the *before/after memory measurement itself* could not be
performed here.

## 16. Testing Strategy

See `PHASE_4_VIEWER_TEST_MATRIX.md` for the full breakdown. Summary:
`scripts/viewer-lifecycle-test.js` (16 checks) provides static,
source-level regression guards for every fix made this phase, following
the same "no browser dependency" convention this project already
established (`scripts/pdf-render-order-test.js`'s own header comment
documents this exact convention and reasoning). Combined with the full
pre-existing suite (Phase 0–3's tests, all re-run, all still passing)
and a direct, real-data classification check against the actual
committed sample evidence in the standards folder.

## 17. Known Limitations

Restated from `PHASE_4_VIEWER_AUDIT.md` §15, unchanged by this phase:
PPTX partial fidelity, no preview for DOC/PPT/RTF/ODT/ODS/ODP, no zoom
for Excel/CSV/PPTX (accurately reflected in the new capability table,
not silently promised), no server-side conversion pipeline, open PDF
Arabic-glyph edge cases pending real repro files (Phase 0). **New
limitation this phase is explicit about, not silent on:** no real
browser/visual verification was possible in this environment — every
fix was verified via static source-structure checks and, for the
`.ppsx` fix specifically, real (read-only) classification testing
against actual committed evidence, but never via actually opening a file
in a rendered window and looking at it. See `PHASE_4_REPORT.md` §15 for
the complete, explicit accounting of what was and was not verified.

## 18. Future Extension Strategy

- **Splitting `viewer.js` by format** (one file per engine, mirroring
  `pdf-engine.js`'s pattern) remains the right long-term direction
  (Phase 0's own §22 already recommended this) — deferred again this
  phase specifically because it requires visual verification this
  environment cannot provide (see `PHASE_4_VIEWER_AUDIT.md` §19's risk
  assessment). A future phase run in an environment with a real display
  (or with an explicitly-approved new test dependency like Playwright)
  is the right time to attempt it.
- **A server-side conversion pipeline** for DOC/PPT/RTF/ODT/ODS/ODP
  (and full-fidelity PPTX) is the natural next step for closing the
  remaining preview gaps — already scoped in `FILE-SUPPORT-ARCHITECTURE-
  REPORT.md`, still not attempted, explicitly out of this phase's scope.
- **Adding new capability flags** (e.g. `zoom: true` for Excel/PPTX, if
  a future phase actually implements it) is now a two-step, guarded
  process: implement the toolbar control in the render function, then
  update the corresponding `VIEWER_CAPABILITIES_BY_ENGINE` entry — the
  static consistency check in `scripts/viewer-lifecycle-test.js` will
  fail if only one of the two steps is done, which is exactly the
  guard-rail a future contributor benefits from.
- **New extensions that reuse an existing engine** (this phase's own
  `.ppsx` fix is the working example) require zero `viewer.js` changes —
  just a new `EXTENSIONS` entry pointing at the right engine name.
