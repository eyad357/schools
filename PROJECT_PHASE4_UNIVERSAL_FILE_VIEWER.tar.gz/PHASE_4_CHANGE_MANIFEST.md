# PHASE 4 — Change Manifest

Working copy: `/home/claude/workspace/phase1-working-copy`
Starting commit (Phase 3 end state): `5a2e282` ("docs: add Phase 3 evidence intake architecture, file support matrix, change manifest, and final report")

Commits this phase:
- `f300d1e` — `fix: viewer lifecycle leaks + broken word/text zoom (Phase 4 audit findings)`
- `07413ef` — `fix: recognize .ppsx (PowerPoint Show) — found via real-file testing`

---

## Modified Files

### `app/js/viewer.js`

| | |
|---|---|
| **Change** | (1) `cleanupPrevious()` now disconnects `pdfObserver`/`pdfPageTracker` and removes the `window`-level image-pan `mousemove`/`mouseup` listeners, in addition to what it already did (PDF document destruction, object URL revocation, media element stop, `mediaCleanup` callback). (2) New `applyContentZoom()` function, dispatching to `applyImageTransform()`/`applyDocZoom()`/the `#dv-text-pre` element's `fontSize` depending on `state.category`; `zoomBy()` now calls it instead of unconditionally calling `applyImageTransform()`. (3) `renderText()`'s initial font-size assignment now scales with `state.zoom` for consistency with the fix in (2). (4) Removed one dead-code line (`const _zoomByBase = zoomBy;`, unreferenced). |
| **Reason** | Two real lifecycle-cleanup gaps and one real functional bug, all found during this phase's mandatory pre-coding audit (`PHASE_4_VIEWER_AUDIT.md` §14, items 1–3) — not speculative improvements. |
| **Architectural role** | Viewer shell (`cleanupPrevious`) and shared toolbar dispatch (`zoomBy`/`applyContentZoom`) — the exact two responsibilities the brief's target architecture assigns to the shell, not to any individual format engine. No format engine's rendering algorithm was touched. |
| **Risk** | Low. Each fix is small (a handful of lines), isolated, and independently verifiable via static source-structure checks without needing to execute the code in a browser. The zoom fix could in principle change visible behavior for word/text zoom (from "does nothing" to "actually zooms") — this is the intended, corrective effect, not a side effect. |
| **Test coverage** | `scripts/viewer-lifecycle-test.js`: 4 checks for the cleanup fixes, 2 for the zoom-dispatch fix (8 of the suite's 16 total checks). Full pre-existing regression suite re-run, zero regressions. |

### `app/js/file-support-policy.js`

| | |
|---|---|
| **Change (Phase 4 part 1)** | New `VIEWER_CAPABILITIES_BY_ENGINE` table (8 entries, one per existing `viewer.js` render engine) and `getViewerCapabilities(filenameOrExt)` function, both exported. |
| **Change (Phase 4 part 2)** | New `ppsx` entry in `EXTENSIONS`, identical in structure to the existing `pptx` entry (category `powerpoint`, `pptx-text-extract` engine, 100MB cap, ZIP signature check, `partial` fidelity) — found missing via real-file classification testing against the standards folder's actual committed sample evidence. |
| **Reason** | Part 1: direct implementation of Phase 4's "Capability Model" requirement, layered over the existing dispatch mechanism rather than replacing it. Part 2: a real, previously-unknown classification gap, found by testing with actual files rather than extension names only, per the brief's explicit "Real File Testing" instruction. |
| **Architectural role** | Both are additions to the existing single source of truth for file classification/policy — no new module, no competing mechanism. |
| **Risk** | Very low for both — pure additive data, no existing extension's policy was changed, no existing function's behavior changed (only new functions/table entries added). The `.ppsx` addition does change *classification outcome* for that one extension (from "unknown, no preview" to "powerpoint, previewable") — a deliberate, evidence-based correction, not a side effect. |
| **Test coverage** | `scripts/viewer-lifecycle-test.js`: 6 checks verify the capability table stays consistent with `viewer.js`'s actual dispatch table and actual toolbar-building calls (including an explicit check that excel/pptx do *not* falsely claim zoom); 2 checks verify the `.ppsx` fix, one of which reads the real committed sample file. `verify:file-support-policy` re-run (63/63, unaffected). |

---

## Files Added

### `scripts/viewer-lifecycle-test.js` (+ `"verify:viewer-lifecycle"` npm script)

| | |
|---|---|
| **Change** | New 16-check static regression-guard suite, following this project's existing "no browser dependency" convention (documented and already used by `scripts/pdf-render-order-test.js`). Covers: the two lifecycle-cleanup fixes, the zoom-dispatch fix, six capability-model-consistency checks (including the two-way "every dispatched engine has a capability entry, every capability entry corresponds to a real dispatched engine" guard), two security re-verification checks (no `eval`/`Function`/`document.write` in `viewer.js`; mammoth output stays inside its scoped container), and two `.ppsx`-specific checks. |
| **Reason** | Direct implementation of Phase 4's "Testing Strategy" requirement, scoped to what is actually verifiable without a display server in this environment (see `PHASE_4_VIEWER_TEST_MATRIX.md` for the full, honest accounting of what could and couldn't be tested here). |
| **Architectural role** | Test-only. |
| **Risk** | None — additive test file. |
| **Test coverage** | The suite is itself the coverage; 16/16 passing, re-run after every subsequent change in this phase. |

### `PHASE_4_VIEWER_AUDIT.md`, `PHASE_4_VIEWER_ARCHITECTURE.md`, `PHASE_4_VIEWER_TEST_MATRIX.md`, `PHASE_4_CHANGE_MANIFEST.md`, `PHASE_4_REPORT.md`

Documentation deliverables required by the brief.

---

## Files Moved

None. Per the audit's explicit risk assessment (`PHASE_4_VIEWER_AUDIT.md`
§19), splitting `viewer.js` into per-format files was considered and
deliberately deferred — not attempted without the ability to visually
verify the result in a real browser, which this environment cannot
provide.

## Files Deleted

None (the one dead-code line removed, `_zoomByBase`, is recorded as part
of the `viewer.js` modification above, not a file deletion).

## Configuration Changed

None.

## Dependencies Added or Changed

**None.** `package.json`'s `dependencies`/`devDependencies` and
`package-lock.json` are both byte-identical to the Phase 3 end state
except the one added npm-script line
(`"verify:viewer-lifecycle": "node scripts/viewer-lifecycle-test.js"`).
No browser-automation library (Puppeteer/Playwright/jsdom) was added,
consistent with the brief's "Dependency Policy" section's requirement to
check whether existing tools solve the problem first — this project's
existing static-verification convention did.

---

## Summary Table

| Change | Files touched | Behavior change | Test evidence |
|---|---|---|---|
| Lifecycle-cleanup fixes (PDF observers, image pan listeners) | `viewer.js` | Yes — resources now correctly released on every close/switch, not just same-format re-open | `viewer-lifecycle-test.js` (4 checks) |
| Zoom-dispatch fix (word/text) | `viewer.js` | Yes — word/text zoom now actually works | `viewer-lifecycle-test.js` (2 checks) |
| Capability model | `file-support-policy.js` | None (purely additive, read-only query surface) | `viewer-lifecycle-test.js` (6 checks) |
| `.ppsx` recognition | `file-support-policy.js` | Yes — this one real file (and any other `.ppsx`) now gets a real preview instead of none | `viewer-lifecycle-test.js` (2 checks, one against the real committed file) |
| New test suite | `viewer-lifecycle-test.js`, `package.json` | None (test-only) | 16/16 |

**Total files touched across Phase 4:** 2 modified (`viewer.js`,
`file-support-policy.js`), 1 test file created, 5 documentation
deliverables created, 0 moved, 0 renamed, 0 deleted. No UI file outside
the viewer was touched (`app/index.html`'s non-viewer markup, dashboard,
navigation, school-structure screens, and licensing UI were not
modified — confirmed via `git diff --stat`). No licensing, backup, or
installer file was touched. The immutable standards directory: 0
changes — verified via SHA-256 comparison after every commit in this
phase.
