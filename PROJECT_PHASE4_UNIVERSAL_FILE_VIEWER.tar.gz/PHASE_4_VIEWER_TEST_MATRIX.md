# PHASE 4 — Viewer Test Matrix

**Read this first, honestly:** this sandboxed environment has **no
display server** — the same limitation documented in every prior phase's
performance/testing sections (Phase 0's PDF investigation, Phase 3's UI-
responsiveness note). It was true before Phase 4 and remains true now.
This means the literal instruction "open representative files, verify
rendering, test controls" **cannot be executed as a real, visual test**
in this environment — there is no Electron window to open, no pixels to
look at, no mouse to click zoom buttons with.

What this document reports instead, per cell, is exactly what **could**
be verified without a display — static source-structure verification
(does the correct render function exist, does it build the toolbar
controls its capability entry claims, does cleanup correctly tear it
down) and, where a real file was available, real classification/
metadata verification (does `FileSupportPolicy` correctly identify and
route the file) — clearly distinguished from actual rendered-pixel
verification, which is marked **NOT TESTABLE IN THIS ENVIRONMENT**
throughout, per the brief's own requirement to "clearly separate PASS /
FAIL / BASELINE FAILURE / NOT TESTABLE IN CURRENT ENVIRONMENT."

---

## PDF

| Case | Classification/routing | Toolbar capabilities present in source | Actual rendered-pixel verification |
|---|---|---|---|
| English | ✅ PASS (`.pdf` → `pdfjs` engine) | ✅ PASS (zoom/fitWidth/fitPage/pageNav/thumbnails/rotate/search/print/fullscreen all present in `renderPdf()`, cross-checked by `viewer-lifecycle-test.js`) | NOT TESTABLE IN THIS ENVIRONMENT |
| Arabic | ✅ PASS (same routing) | ✅ PASS (same toolbar) | NOT TESTABLE IN THIS ENVIRONMENT — the specific Arabic-glyph-corruption bug this codebase previously found and fixed (`PDF-RENDER-CORRUPTION-FIX-REPORT.md`) was fixed and regression-guarded in a prior phase (`verify:pdf-render-order`, still passing); this phase re-read but did not re-render that fix |
| Mixed Arabic/English | Same as above | Same as above | NOT TESTABLE IN THIS ENVIRONMENT |
| Scanned | Same as above | Same as above (no OCR — documented, unchanged limitation) | NOT TESTABLE IN THIS ENVIRONMENT |
| Multi-page | Same as above | ✅ PASS (page navigation + lazy `IntersectionObserver` rendering confirmed present in source; the exact leak this phase fixed was in this observer's cleanup, not its rendering) | NOT TESTABLE IN THIS ENVIRONMENT |
| Embedded fonts | Same as above | Same as above | NOT TESTABLE IN THIS ENVIRONMENT |

**Real file available:** yes — 4 real PDFs exist in the standards
folder's committed sample evidence. Read-only classification check
performed (all 4 correctly resolve to the `pdfjs` engine with full
capabilities); **actually rendering them was not possible** in this
environment.

## PPT/PPTX

| Case | Classification/routing | Toolbar capabilities in source | Actual rendered-pixel verification |
|---|---|---|---|
| Text slides | ✅ PASS (`.pptx`/`.ppsx` → `pptx-text-extract`) | ✅ PASS (slideNavigation/search/fullscreen present in `renderPptx()`) | NOT TESTABLE IN THIS ENVIRONMENT |
| Images | Same routing | Same (embedded-image extraction confirmed present in source, per Phase 0's original investigation) | NOT TESTABLE IN THIS ENVIRONMENT |
| Tables | Same routing | Text-extraction only — tables are **not** specially handled (documented partial-fidelity limitation, unchanged) | NOT TESTABLE IN THIS ENVIRONMENT |
| Arabic | Same routing | Same toolbar | NOT TESTABLE IN THIS ENVIRONMENT |
| Multiple slides / presentation navigation | Same routing | ✅ PASS (slide rail + stage navigation confirmed present in source) | NOT TESTABLE IN THIS ENVIRONMENT |

**Real file available:** yes — one real `.ppsx` file (خطة التحسين
المدرسي.ppsx) in the standards folder's committed sample evidence. This
is the file that surfaced the Phase 4 classification bug (§ audit §14
item 4): **before this phase's fix, it did not resolve to any preview
engine at all.** After the fix, real (read-only) classification testing
confirms it now correctly resolves to `pptx-text-extract` with full
slide-navigation capabilities — this specific, real-file result is a
genuine PASS, not a static-only inference, because it queries the actual
policy module against the actual file's actual name.
**Actually rendering its slides was not possible** in this environment.

## DOC/DOCX

| Case | Classification/routing | Toolbar capabilities in source | Actual rendered-pixel verification |
|---|---|---|---|
| Arabic | ✅ PASS (`.docx` → `mammoth`) | ✅ PASS (search/zoom present in `renderWordDocx()` — **zoom was broken before this phase's fix**, confirmed fixed via the new `applyContentZoom()` static check) | NOT TESTABLE IN THIS ENVIRONMENT |
| English | Same routing | Same toolbar | NOT TESTABLE IN THIS ENVIRONMENT |
| Tables | Same routing | mammoth's own table-conversion behavior, unchanged from before this phase | NOT TESTABLE IN THIS ENVIRONMENT |
| Images | Same routing | mammoth's own embedded-image handling, unchanged | NOT TESTABLE IN THIS ENVIRONMENT |
| Multiple pages | Same routing | mammoth renders as continuous flowed HTML, not paginated (documented, unchanged design — this app's DOCX preview does not paginate) | NOT TESTABLE IN THIS ENVIRONMENT |

**Real file available:** yes — one real `.docx` in the standards
folder's sample evidence. Classification confirmed correct (routes to
`mammoth`). **Actually rendering it was not possible** in this
environment.

## XLS/XLSX

| Case | Classification/routing | Toolbar capabilities in source | Actual rendered-pixel verification |
|---|---|---|---|
| Multiple sheets | ✅ PASS (`.xlsx`/`.xls`/`.xlsm` → `sheetjs`) | ✅ PASS (sheetNavigation/search present in `renderExcel()`; **no zoom, confirmed and correctly NOT claimed in the capability table** — this is a documented absence, not a bug) | NOT TESTABLE IN THIS ENVIRONMENT |
| Arabic | Same routing | Same toolbar | NOT TESTABLE IN THIS ENVIRONMENT |
| Numbers | Same routing | Plain-data table rendering, no number formatting (documented, unchanged) | NOT TESTABLE IN THIS ENVIRONMENT |
| Wide tables | Same routing | No frozen panes (documented, unchanged) | NOT TESTABLE IN THIS ENVIRONMENT |

**Real file available:** yes — one real `.csv` (`robot_sensor_data.xlsx
- Sheet.csv`, an unusual but real filename containing a literal `.xlsx`
substring before the actual `.csv` extension — a useful, if accidental,
real-world test of `getExtension()`'s "last dot wins" logic, confirmed
correct: classifies as `csv` category, not `xlsx`) in the standards
folder's sample evidence. **Actually rendering it was not possible** in
this environment.

## Images (JPG/PNG/SVG)

| Case | Classification/routing | Toolbar capabilities in source | Actual rendered-pixel verification |
|---|---|---|---|
| JPG | ✅ PASS (→ `native-image`) | ✅ PASS (zoom/pan/rotate/gallery/fullscreen present in `renderImage()`) | NOT TESTABLE IN THIS ENVIRONMENT |
| PNG | Same routing | Same toolbar | NOT TESTABLE IN THIS ENVIRONMENT |
| SVG | Same routing | Same toolbar; rendered via `<img>` never inline (existing, correct XSS-safety decision, unchanged) | NOT TESTABLE IN THIS ENVIRONMENT |

**Real file available:** no image file exists in the standards folder's
current sample evidence. Classification verified via the intake test
suite's real-fixture uploads (Phase 3's `verify:evidence-intake`, still
passing) instead — real JPG/PNG signature bytes, confirmed correctly
classified. **Actually rendering an image was not possible** in this
environment.

## Video (MP4)

| Case | Classification/routing | Toolbar capabilities in source | Actual rendered-pixel/playback verification |
|---|---|---|---|
| MP4 | ✅ PASS (→ `native-media-video`) | ✅ PASS (playback/seek/volume/playbackSpeed/fullscreen present in `renderMedia('video')`) | NOT TESTABLE IN THIS ENVIRONMENT |

**Real file available:** no. Verified via Phase 3's intake fixture
(synthetic MP4 bytes — no signature check is defined for video, by
design, so intake-level testing doesn't require real MP4 structure)
routing correctly to the video category. **Actual playback was not
possible** in this environment.

## Audio (MP3)

| Case | Classification/routing | Toolbar capabilities in source | Actual playback verification |
|---|---|---|---|
| MP3 | ✅ PASS (→ `native-media-audio`) | ✅ PASS (playback/seek/volume/playbackSpeed present in `renderMedia('audio')`) | NOT TESTABLE IN THIS ENVIRONMENT |

## Unknown (accepted file, no internal viewer)

| Case | Classification/routing | Fallback behavior in source | Actual rendered verification |
|---|---|---|---|
| Known type, no preview (e.g. `.doc`, `.ppt`, `.odt`) | ✅ PASS (routes to no engine → `renderUnsupportedOffice`) | ✅ PASS (shared error-state message + download link, confirmed present in source, distinct from the generic fallback message) | NOT TESTABLE IN THIS ENVIRONMENT |
| Unknown-but-safe (Phase 3 tier, e.g. `.xyzabc`) | ✅ PASS (routes to no engine → `renderFallback`) | ✅ PASS (generic "no preview" message + download link, confirmed present in source) | NOT TESTABLE IN THIS ENVIRONMENT |

---

## Cross-Viewer / Lifecycle Testing

The brief's mandatory sequence (PDF → PPTX → PDF → DOCX → Image → Video
→ PPTX → PDF) **cannot be executed as a literal click-through sequence**
without a display. What was verified instead, and is the closest honest
equivalent achievable here: **static proof that `cleanupPrevious()` now
tears down every stateful resource any format can create**, checked
individually for each resource type (PDF document + both observers,
object URLs, media element + format-specific `mediaCleanup` callback,
image pan listeners) — see `PHASE_4_VIEWER_AUDIT.md` §14 and §16, and
`scripts/viewer-lifecycle-test.js`'s first four checks. This is a
structural guarantee that switching formats cannot leak the two
resource types this phase found leaking (§ audit), verified by source
inspection; it is **not** a substitute for actually clicking through the
sequence and watching memory in a real window, which remains **NOT
TESTABLE IN THIS ENVIRONMENT**.

## Memory / Cleanup (10+ files, format switching)

**NOT TESTABLE IN THIS ENVIRONMENT** — requires a real browser/Electron
process to open real files and sample memory over time. The two leaks
this kind of test is designed to catch were found instead through direct
source-code reading during the audit (§ audit §14, items 1–2) and fixed;
this is a real, valid, but different verification method than the
brief's literal instruction, and is reported as such rather than
claiming a memory-profiling session that did not happen.

## Regression Testing

**Fully executed, not a static inference.** Every pre-existing automated
suite was re-run in full after every change in this phase:

| Suite | Result |
|---|---|
| `verify:server` | 15/15 |
| `verify:viewer` | 10/19 (9 pre-existing, documented, unrelated fixture-path failures — unchanged since Phase 1A) |
| `verify:part2` | 11/11 |
| `verify:pdf-render-order` | 4/4 |
| `verify:file-support-policy` | 63/63 |
| `verify:part2-remaining` | 12/12 |
| `verify:completion` | 23/23 |
| `verify:standards` | 10/10 |
| `verify:evidence-intake` | 60/60 |
| `verify:viewer-lifecycle` (new) | 16/16 |
| **Total** | **224/233**, same 9 pre-existing failures as every prior phase |

## Standards Integrity

**Fully executed.** Re-run via `node scripts/generate-standards-baseline.js
verify` after every commit in this phase — every run reported
`✅ STRUCTURE IDENTICAL`.

## Phase 3 Intake Regression

**Fully executed**, not just inferred: `verify:evidence-intake`'s full
60-check suite (upload, store, retrieve, checksum, delete, rename,
duplicate handling, security) was re-run after every viewer-layer change
in this phase and remained 60/60 throughout — direct evidence that the
viewer work did not touch or break the intake layer, per the brief's
explicit "Phase 3 Regression" requirement.
