# PHASE 4 — Viewer Audit

Status: written **before** any Phase 4 code change, per the brief's
"First Task — Audit, Not Coding" requirement. The findings below are
what drove every decision in `PHASE_4_VIEWER_ARCHITECTURE.md` and the
changes recorded in `PHASE_4_CHANGE_MANIFEST.md`.

---

## 1. Current Viewer Architecture

```
app/js/viewer.js (1,141 lines, single IIFE exposing `Viewer.open`/`Viewer.close`)
  ├─ DOM scaffold built ONCE (ensureDOM()), reused for every file
  ├─ Shared shell: topbar (icon/filename/subtitle/toolbar/actions),
  │  search bar, sidebar (thumbnails), content area, info panel, status bar
  ├─ Shared lifecycle: open() → cleanupPrevious() → freshState() → dispatch
  ├─ Dispatch table `renderersByEngine`, keyed by FileSupportPolicy's
  │  `preview.engine` string — NOT a per-extension if/else chain
  └─ 8 format-specific render functions, each building only its own
     toolbar controls + content area via shared helper functions
     (addToolBtn, addZoomControls, addSearchToggle, showLoading, showError)
```

This is **already** a "shared shell + format engines via one central
dispatch" architecture — not a giant `if/else` chain, and not eight
unrelated pages. The brief's "Core Product Principle" section describes
almost exactly what already exists here.

## 2. Current Viewer Dispatch Mechanism

`FileSupportPolicy.getPolicy(filename).preview.engine` → looked up in
`renderersByEngine` (a flat object literal, `open()`'s local scope) →
matching render function called. Adding a new *engine* means one new
table entry + one new render function; adding a new *extension* that
reuses an existing engine (this phase's own `.ppsx` fix is a real
example) means one new `EXTENSIONS` entry, zero `viewer.js` changes.
This already **is** the "ViewerResolver" concept the brief asks for, in
data-driven form — Phase 4 formalizes it further (§6 below) rather than
replacing it.

## 3. Current Shared UI

Confirmed shared, not duplicated, across every format: topbar (icon,
filename, subtitle, toolbar mount point, info/fullscreen/download/close
actions), search bar (one generic implementation used by word/excel/
text/pptx; PDF has its own page-aware variant, documented as
intentional), sidebar (repurposed for PDF thumbnails only today — see
§12), content area, info panel (`buildInfoPanel()` — filename, type,
size, modified date, indicator code, shared across every format, with a
per-format `setInfoExtra()` extension point already in use by
PDF/PPTX/media), status bar, loading/error states (`showLoading`/
`showError`, used by all 8 render functions), keyboard handling
(`onKeydown` — Escape, F, Ctrl+F, +/-, arrow keys for gallery — one
handler, registered once).

## 4. Current Format-Specific Implementations

| Format | Function | Real capabilities wired up today |
|---|---|---|
| PDF | `renderPdf` | zoom, fit-width, fit-page, rotate, page navigation (input + prev/next + scroll tracking), thumbnails sidebar, search (page-aware, full-document backfill), print, remembers last-viewed page per file (session-only) |
| Word (.docx) | `renderWordDocx` | search, zoom (**broken before this phase — see §14**) |
| Excel/CSV | `renderExcel` | sheet tabs, search — **no zoom** (never was; not a bug, a capability that was never added) |
| PowerPoint (.pptx) | `renderPptx` | slide navigation (rail + stage), search — **no zoom**, no fullscreen-specific slide layout beyond the shared shell's own fullscreen |
| Image | `renderImage` | zoom, pan (drag + wheel), rotate, gallery navigation (prev/next across sibling images in the same folder, keyboard arrow keys) |
| Video | `renderMedia('video')` | play/pause, seek with hover-scrub thumbnail preview, volume/mute, playback speed, skip ±10s, double-click fullscreen |
| Audio | `renderMedia('audio')` | play/pause, seek, volume/mute, playback speed, skip ±10s |
| Text | `renderText` | search, zoom (**broken before this phase — see §14**) |
| No-preview types (doc/ppt/odt/ods/odp) | `renderUnsupportedOffice` | shared error-state message directing to external-open |
| Truly unrecognized (archives, unknown-but-safe) | `renderFallback` | shared generic "no preview" message |

## 5. Existing PDF Implementation

`app/js/pdf-engine.js` (292 lines) is the single source of truth for all
pdf.js configuration (worker/cmap/font paths, version pinning, error
classification) — already centralized, already fixed the specific
Arabic-rendering corruption bug documented in
`PDF-RENDER-CORRUPTION-FIX-REPORT.md` (root cause: rendering into a
canvas already attached to the live DOM changes Chromium's native font
rasterization path for certain embedded TrueType hinting tables — fixed
by always rendering off-DOM, attaching only after render completes, and
guarded by `scripts/pdf-render-order-test.js`'s static invariant check).
`viewer.js`'s `renderPdf`/`renderAllPdfPages`/`buildPdfThumbnails` all
correctly follow this render-off-DOM-then-attach contract, re-verified
during this audit by re-reading every canvas-creation call site.

**Not re-investigated in this phase** (per the brief's own instruction
not to blindly re-fix a documented, evidence-based prior finding): the
one genuinely open PDF item from Phase 0, Arabic glyph-joining edge
cases for PDF generators nobody has sent a repro file for yet
(`PDF-RENDERING-NOTES.md`). Still open, still requires a real repro file
this environment does not have.

## 6. Existing PPT/PPTX Implementation

Client-side JSZip-based OOXML slide-XML text/image extraction —
deliberately labeled `fidelity: 'partial'` everywhere it's surfaced
(policy notes, in-viewer info panel). Extracts title + bullet text +
embedded raster images per slide; does **not** reproduce layout, fonts,
positioning, animations, transitions, embedded video/audio, charts,
SmartArt, or speaker notes. This is a documented, deliberate scope
limit from a prior phase (Phase 0 §12, `FILE-SUPPORT-ARCHITECTURE-
REPORT.md` §G — the same report already proposes a server-side
LibreOffice-headless-conversion-to-PDF path as the way to eventually
close this gap, explicitly scoped as future work).

## 7. Existing DOC/DOCX Implementation

mammoth.js, converts `.docx` to HTML client-side, rendered into a
scoped `#dv-office-doc` container. No preview at all for legacy `.doc`
(binary format, no reliable client-side parser exists — same reasoning
as PPT). Word count shown in the info panel; a "some formatting
simplified" notice shown when mammoth reports conversion warnings.

## 8. Existing Spreadsheet Implementation

SheetJS, converts the active sheet to an HTML table; sheet-tab UI for
multi-sheet workbooks; used for both `.xlsx`/`.xls`/`.xlsm` and `.csv`
(same engine, `csv` is its own FileSupportPolicy category but shares the
`sheetjs` preview engine). No frozen-pane support, no cell-level
formatting (borders/colors/number formats) — a plain-data table view,
consistent with the brief's own "do not pretend to be Excel" guidance.

## 9. Existing Image Implementation

Native `<img>` (deliberately never inline `<svg>`, even for `.svg`
files — an existing, correct XSS-safety decision documented in
`FileSupportPolicy`, re-confirmed during this audit, not touched).
Zoom (buttons + mouse wheel), pan (drag), rotate (90° steps), gallery
mode (automatically activated when other images exist in the same
indicator folder — arrow-key and on-screen prev/next navigation).

## 10. Existing Media Implementation

Fully custom-themed controls over the native `<video>`/`<audio>`
element (no browser-default controls shown) — play/pause, seek with a
buffered-range indicator and a hover-scrub thumbnail preview (a hidden
shadow `<video>` clone seeks ahead of the cursor and grabs a frame,
cached per ~2-second bucket), volume/mute, playback speed (0.5×–2×),
skip ±10 seconds, double-click-to-fullscreen for video.

## 11. Existing Fallback Behavior

Two distinct, correctly-differentiated fallback states — confirmed
neither is a "broken blank viewer" or a raw JS error, satisfying the
brief's explicit requirement: `renderUnsupportedOffice()` (a *known*
type with no internal preview — doc/ppt/odt/ods/odp) shows a message
specifically saying the format can't be previewed *yet* and offers
download; `renderFallback()` (a genuinely unrecognized/no-policy type)
shows a more generic "no preview available" message. Both route through
the same `showError()` shared-state helper, so they're visually
consistent with every other error state in the shell (corrupted file,
failed fetch, etc.).

## 12. Duplicated Code

**Very little found.** The one real duplication risk area — PDF
configuration — was already fixed in a prior phase (`pdf-engine.js`
consolidation). No second copy of extension→category/icon/label logic
exists (confirmed via grep across `app/`, matching Phase 0's original
finding that this was already fixed). The sidebar element is currently
single-purpose (PDF thumbnails only) rather than a generic "format may
use a sidebar" concept — not duplication, but worth noting as a
naming/reuse opportunity for a future phase if another format ever needs
a sidebar (e.g. PPTX slide thumbnails).

## 13. Tight Coupling

Minimal. `viewer.js` does not import/depend on evidence-storage,
licensing, or backup code (confirmed via grep — its only external
dependencies are `FileSupportPolicy`, `PDFEngine`, and the three bundled
parser libraries `mammoth`/`XLSX`/`JSZip`, plus `fetch()` calls to the
same HTTP API every other renderer module uses). The one coupling worth
naming: `zoomBy()` previously assumed every category zooms the same way
(§14) — a real, now-fixed instance of the shared shell's zoom control
being wired to only one format's actual implementation.

## 14. Existing Bugs (found during this audit, before any code change)

1. **`cleanupPrevious()` did not disconnect the PDF viewer's two
   `IntersectionObserver`s** (lazy page rendering, current-page
   tracking) except as a side effect of opening *another* PDF next.
   Closing the viewer entirely, or switching to a non-PDF format, left
   both alive and registered, referencing the old document's page
   objects. **Fixed this phase** — see `PHASE_4_CHANGE_MANIFEST.md`.
2. **`cleanupPrevious()` did not remove the image viewer's `window`-level
   drag-to-pan listeners** except as a side effect of opening *another*
   image next. Bounded (never more than one stale pair) but real.
   **Fixed this phase.**
3. **`zoomBy()` unconditionally called `applyImageTransform()`**
   regardless of category — a silent no-op for word/text, whose zoom
   +/- toolbar buttons updated the percentage label while visibly
   changing nothing. **Fixed this phase.**
4. **`.ppsx` (PowerPoint Show) was entirely missing from
   `FileSupportPolicy`'s `EXTENSIONS` table** — found by testing
   classification against the real sample evidence already committed in
   this repo (one of the standards folder's 7 real files is a `.ppsx`).
   It fell into the Phase 3 "unknown but safe" bucket with no preview,
   despite the existing `pptx-text-extract` engine already being fully
   capable of rendering it (identical OOXML structure to `.pptx`).
   **Fixed this phase.**
5. **A one-line dead-code leftover** (`const _zoomByBase = zoomBy;`,
   an apparently unfinished prior attempt at the same zoom-dispatch fix,
   never referenced anywhere) — removed as part of the zoom fix above.

None of these are the "known baseline PDF/PowerPoint rendering issues"
the brief says not to touch (§17/§18 below) — all five are architectural/
lifecycle/classification issues, not fidelity issues, and are exactly
the class of problem this phase's brief explicitly asks to be found and
fixed ("architectural problems" vs. "actual format-rendering problems,"
per the audit's own §25/§26 framing).

## 15. Existing Limitations (not bugs — documented, deliberate scope boundaries)

- PPTX preview: partial fidelity (text + images only), by design.
- DOC/PPT/RTF/ODT/ODS/ODP: no internal preview at all, by design
  (no reliable client-side parser exists for these formats).
- Excel/CSV and PPTX have no zoom control (never implemented; not a
  regression, since it never worked — confirmed via this audit's direct
  code reading, not assumed).
- No server-side conversion pipeline exists (e.g. LibreOffice-headless)
  — everything renders client-side via bundled JS libraries only.
- Search is generic text-highlighting for word/excel/text/pptx (works
  on whatever text made it into the DOM); PDF has its own dedicated
  page-aware search. No search inside images/video/audio (not
  applicable to those formats).

## 16. Security Concerns

Reviewed against the brief's explicit checklist:

| Concern | Finding |
|---|---|
| Uploaded JS ever executed | No — `viewer.js` has zero `eval`/`Function`/`document.write` usage anywhere (grep-verified, and now a permanent regression guard in `scripts/viewer-lifecycle-test.js`) |
| Uploaded HTML loaded into a privileged context | No — mammoth's HTML output lands inside a scoped `#dv-office-doc` `<div>` in the same sandboxed renderer process; no `<iframe>`, no `webview`, no separate BrowserWindow is ever created for file content |
| Uploaded content gains Node.js access | No — `viewer.js` runs entirely in the sandboxed renderer (confirmed: no `require()`, no `ipcRenderer` usage anywhere in this file) |
| Arbitrary filesystem paths reachable from the renderer | No — every file reference is a `fetch()`/`<img src>`/`<video src>` to the same `/api/file/:code/:name` HTTP endpoint every other screen already uses; no raw filesystem path is ever constructed or exposed in the renderer |
| External-open passes arbitrary strings to a shell | No — re-confirmed unchanged: `POST /api/open-file/:code/:name` (server-side, Phase 0-audited) resolves the code+name through the same trusted `folderForCode`/`getFilePath` path-containment logic every other evidence-file endpoint uses, then calls `shell.openPath()` on that one resolved path — never a user-supplied raw string, never `exec`/`execSync` |
| Object URLs / temp files leaked | Object URLs: tracked in `state.objectUrls`, revoked in `cleanupPrevious()` (pre-existing, re-verified correct). No conversion pipeline exists in this phase, so no temporary conversion files exist to leak. |

**No new security concern found or introduced.** The two lifecycle
leaks (§14, items 1–2) are resource-cleanup issues, not security
boundary issues — nothing they left behind was reachable outside the
already-sandboxed renderer.

## 17. Proposed Target Architecture

See `PHASE_4_VIEWER_ARCHITECTURE.md` for the full writeup. Summary: keep
the existing shell + dispatch-by-engine mechanism (already sound),
formalize the implicit "what can this format's toolbar do" knowledge
into an explicit, data-driven capability table
(`FileSupportPolicy.VIEWER_CAPABILITIES_BY_ENGINE` — added this phase),
fix the lifecycle/classification bugs found above, and defer the larger,
higher-risk structural change (splitting `viewer.js` into one file per
format engine) to a future phase, per the reasoning in §19 below.

## 18. Migration Strategy

**No migration was needed.** Every change this phase made is additive
or corrective within the existing file structure — no file was moved,
split, or renamed. This was a deliberate choice (see §19), not an
oversight.

## 19. Risk Assessment

| Option considered | Risk | Decision |
|---|---|---|
| Rewrite `viewer.js` from scratch into a "true" per-engine module system | High — 1,141 lines of already-working, already-tested (indirectly, via the intake/policy test suites and the PDF render-order regression guard) rendering logic, in a codebase this audit found to have **no display server available for visual verification**. A rewrite with no way to visually confirm the result still renders correctly is exactly the kind of change Phase 1's "if uncertain, keep it" principle warns against. | **Rejected.** |
| Split `viewer.js` into per-format files (`pdf-viewer.js`, `word-viewer.js`, etc.), keeping each function's logic unchanged, just relocated | Medium — mechanical relocation is lower-risk than a rewrite, but with 1,141 lines of interdependent shared-state code (`state`, `dom`, `zoomBy`, `applyContentZoom`, `showLoading`/`showError` all called across every render function) and no way to load the module and click through it, a naive split risks a script-loading-order or shared-helper-visibility mistake that would only surface at runtime, in a real browser, which this audit cannot access. | **Deferred to a future phase** — flagged as a real, valid future direction (matching Phase 0's own original §22 recommendation), not attempted here without visual verification capability. |
| Add a formal, data-driven capability model as a layer ON TOP of the existing dispatch table, with a static two-way consistency check against it | Low — purely additive, verifiable without a browser (the capability claims are checked against what each render function's *source code* actually calls, not against runtime behavior), and gives the "ViewerResolver" concept the brief asks for without touching any rendering logic. | **Implemented this phase.** |
| Fix the two lifecycle leaks and the zoom-dispatch bug found during the audit | Low — each is a small, isolated, well-understood change (a handful of lines each), each independently verifiable via static source-structure checks, each addressing a real, concretely-identified defect rather than a speculative improvement. | **Implemented this phase.** |
| Add the missing `.ppsx` policy entry | Very low — a pure data-table addition, zero `viewer.js` changes required (the existing engine already handles the format), directly justified by testing against real committed evidence. | **Implemented this phase.** |

This risk assessment is the direct basis for why this phase's actual
code changes are narrow and surgical rather than a broad rewrite — see
`PHASE_4_CHANGE_MANIFEST.md` for the complete, itemized list.
