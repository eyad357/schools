# PHASE 3 — Evidence Intake Architecture

Status: **COMPLETE**. Original repository untouched; all changes live
exclusively in `/home/claude/workspace/phase1-working-copy`.

---

## 1. Existing Intake Architecture (before this phase)

Traced end-to-end from the actual code (Phase 0's audit already
documented most of this; re-verified here against the Phase-1/2-refactored
code, not re-derived from scratch):

```
User selects/drops a file (app/js/uploader.js)
  → client-side pre-check via FileSupportPolicy.classifyUpload() — advisory only
  → raw request body = file bytes; x-filename header = original name
    (NOT multipart — a raw-body upload)
POST /api/upload/:code (server/routes/files.js#handleUpload)
  → resolve target dir via evidenceService.folderForCode(code)
  → filename = path.basename(decodeFilename(x-filename header))
  → FileSupportPolicy.classifyUpload() — AUTHORITATIVE server-side re-check
      - extension allow-list only (archives + anything unrecognized: reject)
      - per-type size cap
      - magic-byte signature check where defined
  → on success: fs.writeFileSync(destPath, body) — DIRECT, UNCONDITIONAL WRITE
  → audit log entry, JSON response { success: true, filename }
```

**What Phase 0's audit already flagged, re-confirmed here before making
any change:**
- Filesystem write logic lived inline in the route handler (Phase 1 already
  moved it into `evidenceService.writeEvidenceFile()`, but that function's
  body, until this phase, was still just `fs.mkdirSync` + `fs.writeFileSync`
  — the *ownership* was fixed in Phase 1, the *behavior* is what Phase 3
  changes).
- Upload was an allow-list-only model: archives (`zip`/`rar`/`7z`/`tar`/`gz`)
  had `upload.allowed: false`, and any extension not already present in the
  `EXTENSIONS` table was unconditionally rejected as `UNSUPPORTED_TYPE`.
- `fs.writeFileSync` uses the default `'w'` flag, which **silently
  truncates and replaces any existing file at that path** — uploading a
  file with a name that already existed in that indicator's folder
  silently overwrote it. **This was a real, undiscussed data-loss bug**,
  not a documented product decision (unlike the deliberate "watcher never
  hides OS-dropped files" policy) — found during this phase's own
  investigation, not carried over from a prior report.
- No checksum, no atomic-write guarantee (a crash mid-`writeFileSync`
  could leave a truncated file sitting under a real evidence filename),
  and upload-side filename validation was limited to `path.basename()`
  (path-traversal-safe, but no check for Windows reserved device names,
  trailing dots/spaces, or excessive length — the rename endpoint had
  *some* of these checks inline; the upload endpoint had none of them).
- Storage-error responses echoed `err.message` from raw Node `fs` errors
  directly to the HTTP client, which can include the full absolute path
  being operated on.

---

## 2. New Intake Architecture

```
User selects/drops a file (app/js/uploader.js — UNCHANGED, no UI touched)
  → client-side pre-check via FileSupportPolicy.classifyUpload() — advisory only
POST /api/upload/:code (server/routes/files.js#handleUpload — unchanged shape)
  → resolve target dir via evidenceService.folderForCode(code)
  → filename = path.basename(decodeFilename(x-filename header))    [unchanged: first-line traversal defense]
  → FileSupportPolicy.classifyUpload() — AUTHORITATIVE, now:
      1. validateFilename()  — Windows reserved names / trailing dot-space /
         length cap / disallowed characters  [NEW]
      2. EMPTY_FILE check (size <= 0)         [NEW]
      3. three-tier extension policy:
           KNOWN        → existing per-type size/signature rules (unchanged)
           DANGEROUS    → deny-list, always rejected                [NEW]
           UNKNOWN-SAFE → accepted, category 'other', capped at 50MB [NEW]
  → on success: evidenceService.writeEvidenceFile(dir, filename, body)
      1. generateNonConflictingName() — never overwrites            [NEW]
      2. sha256Buffer() computed from the in-memory buffer          [NEW]
      3. write to a same-directory hidden temp file                 [NEW]
      4. verify written size == input size                          [NEW]
      5. fs.renameSync() into the final name — atomic                [NEW]
      6. best-effort temp-file cleanup on any failure                [NEW]
      → returns { destPath, filename, size, sha256 }
  → on any thrown error: classifyStorageError() maps Node's error code
    to a structured, user-safe reason (never echoes err.message)    [NEW]
  → audit log entry (notes if auto-renamed), JSON response
    { success: true, filename, originalFilename, size, sha256 }     [NEW fields]
```

**Everything upstream of `classifyUpload`/`writeEvidenceFile` — the UI,
the client-side pre-check, the HTTP endpoint shape and URL, the
`x-filename` header convention, the audit-log mechanism, the SSE
watcher pickup — is completely unchanged.** This phase's changes are
concentrated in exactly two files' internal logic
(`app/js/file-support-policy.js`, `server/services/evidenceService.js`)
plus the response-shaping/error-mapping in `server/routes/files.js` that
necessarily follows from them.

---

## 3. File Classification

Unchanged in mechanism (`FileSupportPolicy.getCategory()`/`getPolicy()`,
still the single source of truth, still centralized — Phase 0's original
"seven independently-drifting tables" problem remains fixed and was not
reopened). What changed is the **policy** the classifier applies at the
upload boundary specifically (`classifyUpload`), not the classification
mechanism itself:

| | Before Phase 3 | After Phase 3 |
|---|---|---|
| Known extension (42 entries) | Existing per-type rules | Unchanged |
| Archive (zip/rar/7z/tar/gz) | `upload.allowed: false` | `upload.allowed: true`, capped at 300MB, category `archive`, no preview |
| Unrecognized extension | Always rejected (`UNSUPPORTED_TYPE`) | Accepted as category `other`, capped at 50MB, no preview — **unless** on the new deny-list |
| Executable/script extension (36 entries) | Not distinguished from any other unrecognized extension | Always rejected (`DANGEROUS_TYPE`), regardless of size or content |

Category is metadata only, as the brief requires — it does not imply
preview support. `preview.supported` remains an independent field on
every policy entry (unchanged from Phase 0's already-correct
upload/preview decoupling — see `PHASE_3_FILE_SUPPORT_MATRIX.md`).

---

## 4. Validation Pipeline

Executed in this exact order inside `classifyUpload()` (fail-fast, cheapest/safest checks first):

1. **Filename safety** (`validateFilename`) — reserved chars, Windows
   device names, trailing dot/space, length ≤ 150 chars. Independent of
   file type; runs before anything else so a bad filename never gets
   as far as a type/size verdict.
2. **Non-empty** — `size > 0` required.
3. **Type tier** — known / dangerous / unknown-safe (see §3).
4. **Size** — per-category cap (known types) or the 50MB unknown-safe
   default, checked only after tier is resolved.
5. **Magic-byte signature** — only for known types with a defined
   signature; soft/best-effort for SVG, hard-reject for PDF/PNG/JPEG/
   ZIP-family/OLE-family/GIF/BMP/RAR/7z/GZIP/WebP.

Every step returns a structured `{ ok, reason, friendlyTitle,
friendlyDetail }` — no step silently passes through on a null/undefined
check.

---

## 5. Storage Pipeline

See `evidenceService.writeEvidenceFile()` in full — summarized:

```
mkdirSync(dir, {recursive:true})
finalName = generateNonConflictingName(dir, filename)     // "x.pdf" -> "x (1).pdf" if taken
sha256 = sha256(body)                                       // from the in-memory buffer
tempPath = dir/".{finalName}.uploading-{pid}-{ts}-{rand}"
try:
  writeFileSync(tempPath, body)
  assert statSync(tempPath).size === body.length            // catches a truncated write
  renameSync(tempPath, destPath)                             // atomic on same filesystem
catch:
  best-effort unlinkSync(tempPath) if it exists
  rethrow
return { destPath, filename: finalName, size, sha256 }
```

**Why rename-based atomicity, not a database transaction:** this
application has no database (a deliberate, pre-existing architectural
choice — Phase 0's audit documented "SQLite was intentionally replaced
with an atomic JSON store"). `fs.rename()` on the same filesystem is
atomic on both POSIX (`rename(2)`) and Windows (`MoveFileEx`), which is
the standard, correct way to achieve "no half-written file under a real
name" without a database — this is the same pattern the existing
`server/store/store.js` already uses for its own atomic JSON writes
(confirmed by reading that file: it also does write-to-temp-then-rename).
This phase's storage pipeline is therefore *consistent with* an existing,
already-battle-tested pattern in this codebase, not a new one invented
from scratch.

---

## 6. Metadata Model

**What this phase adds, per upload:** `{ filename, originalFilename,
size, sha256 }`, returned in the HTTP response and partially recorded in
the audit log (the audit log already existed; this phase adds a note
when auto-rename occurred, and the checksum is available via the
response but is **not** persisted to the audit log verbatim, to avoid
audit-log bloat — see "Known Limitations" for the trade-off this implies).

**What this phase deliberately does NOT add:** a separate evidence
database/table with a UUID-based evidence ID, an `evidence_id` column,
or any persistent per-file metadata record beyond the audit log entry
and the file's own on-disk name/content. This is a deliberate scope
decision, not an oversight:

- The brief's own instructions repeatedly emphasize "preserve
  compatibility with the existing application and evidence structure,"
  "do not migrate existing evidence," and "DO NOT redesign the existing
  school evidence directory structure without explicit authorization."
- This application's core, deliberate product property — confirmed
  across Phase 0 through Phase 2's audits — is that the evidence tree is
  **directly Explorer-browsable**: a school's IT staff can open the
  installed folder and see real files with real names, no database
  required to interpret them. Introducing a UUID-based storage identity
  (files named by opaque ID, with the human filename living only in a
  side database) would break that property for every future evidence
  file, and would require a parallel compatibility layer for the
  thousands of already-existing, filename-identified evidence files a
  real school install may already have — exactly the kind of redesign
  the brief says needs "explicit authorization," which this phase does
  not have.
- **What this phase does instead, as the pragmatic middle ground:** the
  physical filename remains the practical identity for browsing/display
  (unchanged), while the SHA-256 checksum returned on every upload gives
  the *application* a content-based identity signal it can use later
  (e.g., detecting that two differently-named files are byte-identical,
  or that a file's content has changed since it was first seen) without
  requiring a database migration today. This satisfies the *spirit* of
  "don't use the filename as the sole identity" using infrastructure
  that already exists (the JSON store's audit log), while leaving a full
  DB-backed evidence-ID model as an explicit, flagged recommendation for
  a future phase that has the product-owner sign-off such a structural
  change deserves (see "Recommendations for Phase 4").

---

## 7. Security Model

| Threat | Mitigation | Status |
|---|---|---|
| Path traversal via filename | `path.basename()` strips all directory components before the filename ever reaches a path-join; containment re-checked (`startsWith(path.resolve(dir))`) as defense-in-depth | Unchanged (already correct pre-Phase-3), re-verified with 10 new automated payload tests (§ testing) |
| Windows reserved device names | `validateFilename()` rejects `CON`/`PRN`/`AUX`/`NUL`/`COM1-9`/`LPT1-9`, bare or with any extension | **New this phase** |
| Executable/script upload | `DANGEROUS_EXTENSIONS` deny-list, checked before the unknown-safe fallback ever applies | **New this phase** |
| Archive bomb / unreviewable nested content | Archives are stored as opaque bytes; **never** extracted, inspected, or unpacked by this application at any point — grep-verified (`unzip\|extract\|jszip\|adm-zip` absent from `evidenceService.js`) | **New this phase (archives are newly accepted, so this is a new-but-addressed risk)** |
| Uploaded content executed/interpreted | Intake is byte-storage only — no `eval`, `Function`, `child_process`, or `vm` usage anywhere in the intake path (grep-verified) | Unchanged, re-verified |
| Silent overwrite of existing evidence | `generateNonConflictingName()` — never overwrites | **New this phase (closes a real gap)** |
| Non-atomic write leaving a corrupt file under a real name | Temp-file-then-rename | **New this phase (closes a real gap)** |
| Raw filesystem error detail (paths, error internals) reaching the client | `classifyStorageError()` maps to structured codes; raw error logged server-side only | **New this phase (closes a real gap)** |
| Symlink/junction escape | See "Known Limitations" — assessed, not additionally engineered against |

**Symlinks/junctions — assessed but not additionally engineered
against.** The write path's only inputs that could theoretically involve
a symlink are (a) the indicator folder itself (`dir`, always resolved
via the trusted manifest-driven `folderForCode()`, never user-supplied)
and (b) the filename (always `path.basename()`'d — cannot contain a
path, so cannot itself reference a symlink elsewhere on disk).
`fs.writeFileSync`/`fs.renameSync` follow symlinks for the *directory*
components of a path but the app never lets a user control which
directory those calls target. The only way a symlink could matter here
is if `dir` itself had been replaced with a symlink pointing outside the
evidence root by someone with prior filesystem write access — which is
already outside this application's threat model (per Phase 0's security
audit: the renderer is sandboxed and reachable only via `127.0.0.1`; a
local attacker with independent filesystem write access to the install
directory can already do arbitrary damage without needing this feature
at all). Per the brief's own "do not over-engineer unsupported OS cases"
instruction, this was assessed and documented rather than mitigated with
additional runtime symlink-detection code.

---

## 8. Error Model

Structured reason codes, returned in every rejection response's
`reason` field (never a bare 500 with a raw message, except for truly
unclassified errors, which still get a generic `UNKNOWN_ERROR` label
rather than the raw text):

| Reason | HTTP status | Meaning |
|---|---|---|
| `INVALID_FILENAME` | 400 | Reserved name / bad characters / too long / trailing dot-space |
| `EMPTY_FILE` | 400 | Zero-byte upload |
| `DANGEROUS_TYPE` | 415 | Extension on the executable/script deny-list |
| `TYPE_BLOCKED` | 415 | A known extension explicitly marked `upload.allowed:false` (mechanism kept for future use; nothing currently uses it, since archives were the only prior example and are now allowed) |
| `TOO_LARGE` | 415 | Over the per-category or unknown-safe size cap |
| `SIGNATURE_MISMATCH` | 415 | Magic bytes don't match the claimed extension |
| `STORAGE_ERROR` | 500 | Disk-full / path-inaccessible class of `fs` error |
| `PERMISSION_DENIED` | 500 | `EACCES`/`EPERM`/`EROFS`-class `fs` error |
| `UNKNOWN_ERROR` | 500 | Any other unclassified `fs`/runtime error |

Rename's error mapping extended with three new reasons
(`NAME_TOO_LONG`, `TRAILING_DOT_OR_SPACE`, `RESERVED_NAME`) alongside the
existing ones (`UNKNOWN_INDICATOR`, `INVALID_CHARS`, `INVALID_PATH`,
`SOURCE_NOT_FOUND`, `NOT_A_FILE`, `DUPLICATE`).

---

## 9. Duplicate Handling

**Policy chosen: generated unique storage identity (Explorer-style
disambiguation), not silent overwrite, not outright rejection.**

Uploading `report.pdf` when `report.pdf` already exists in that
indicator's folder now stores the new file as `report (1).pdf` (then
`report (2).pdf`, etc., following the exact naming convention Windows
Explorer itself already uses for copy conflicts — chosen specifically so
school staff encounter a pattern they already recognize, not an invented
one). The HTTP response reports the *actual* stored filename plus the
originally-submitted filename, and the audit log notes when a rename
occurred. **No data is ever lost or silently replaced.**

This was chosen over "reject the upload and ask the user to rename"
(more friction for a routine, non-error situation — two evidence files
legitimately can share a base name, e.g. photos from two different
events) and over "invent a versioning system" (the product does not
currently have any concept of file versioning, and the brief explicitly
says not to invent a replacement workflow the product doesn't already
have).

---

## 10. Atomic Storage Strategy

Covered in full in §5. Summary of the failure-safety guarantee this
provides:

- **Crash/kill during write:** the in-progress bytes are in the hidden
  `.{name}.uploading-*` temp file, never under the real evidence
  filename. A restart sees no new evidence, exactly as if the upload had
  never started — no half-file confusingly present in the file grid.
- **Disk full during write:** `fs.writeFileSync` throws before the
  rename step is ever reached; the temp file (whatever partial bytes made
  it to disk) is best-effort cleaned up; the function throws, the route's
  `classifyStorageError()` reports `STORAGE_ERROR`, no success response is
  ever sent.
- **Write completes but is short (rare, filesystem-dependent):** the
  explicit `statSync(tempPath).size === body.length` check catches this
  before the rename ever happens, so a truncated file can never become
  the "real" evidence file.

---

## 11. Existing Evidence Compatibility

**No existing evidence file was read, migrated, moved, renamed, or
touched by this phase in any way.** The changes in this phase affect
exactly one code path: what happens when a *new* file is written. The
*read* path (`evidenceService.listFiles()`, `getFilePath()`, `GET
/api/file/:code/:name`) is completely unchanged — any evidence a school
already has on disk today is read exactly the same way after this phase
as before it. Verified directly: `scripts/evidence-intake-test.js`
Level 7 confirms previously-created evidence remains listed and
retrievable after this phase's changes are active; the standards-folder
SHA-256 integrity check (unrelated evidence content, but the same
underlying filesystem tree) was re-run and reported `STRUCTURE
IDENTICAL` at every step of this phase.

---

## 12. Supported / Recognized File Categories

See `PHASE_3_FILE_SUPPORT_MATRIX.md` for the complete, generated matrix.
Summary: 42 explicitly-known extensions across 10 categories (pdf, word,
excel, csv, powerpoint, image, video, audio, text, archive), plus a new
open-ended "unknown but safe" bucket (category `other`) covering any
extension not explicitly known and not on the 36-extension dangerous
deny-list.

---

## 13. Unknown File Policy

Explicitly, per the brief's requested distinction:

- **KNOWN + SUPPORTED (preview available):** pdf, docx, xlsx/xls/xlsm/csv,
  pptx (partial), images, video, audio, text formats — unchanged from
  before this phase.
- **KNOWN + NO INTERNAL VIEWER:** doc, rtf, odt, ods, ppt, odp — accepted,
  stored, external-open only. Unchanged from before this phase.
- **UNKNOWN + SAFE TO STORE:** any extension not in the `EXTENSIONS` table
  and not on `DANGEROUS_EXTENSIONS` — **new this phase**. Accepted,
  stored, category `other`, external-open only, capped at 50MB.
- **INVALID / DANGEROUS / UNSUPPORTED:** the 36-extension deny-list
  (executables, scripts, installers, drivers, shortcuts) — always
  rejected regardless of size or content, `DANGEROUS_TYPE`.

---

## 14. Upload vs Preview Distinction

Maintained and strengthened, not newly invented (Phase 0's audit already
found this substantially decoupled — see that report's §10). Every
`EXTENSIONS` entry (and the new synthetic "unknown" policy object
`classifyUpload` constructs on the fly) carries independent
`upload.allowed` and `preview.supported` booleans. This phase's changes
only ever flip `upload.allowed` (archives: false→true) or add new
policy objects with `preview.supported: false` (unknown-safe) —
**no preview capability was added, changed, or implied anywhere in this
phase**, consistent with the brief's explicit "NO VIEWER IMPLEMENTATION
IN THIS PHASE" instruction.

---

## 15. Testing Strategy

`scripts/evidence-intake-test.js` (`npm run verify:evidence-intake`),
60 checks across all 7 levels the brief specified:

| Level | Checks | Focus |
|---|---|---|
| L1 Unit | 12 | Classification, filename validation, size limits, dangerous deny-list, unknown-safe tier, checksum determinism, non-conflicting-name generation, error mapping |
| L2 Filesystem integration | 7 | Real temp-dir writes, no leftover temp files, duplicate-no-overwrite, HTTP retrieval, failure-path cleanup, invalid-indicator rejection, EACCES error classification |
| L3 Real fixtures | 13 | Signature-valid PDF/DOCX/PPTX/XLSX/JPG/PNG/SVG/MP4/MP3/TXT/CSV/JSON/ZIP, uploaded end-to-end with checksum + retrieval verification |
| L4 Malformed files | 9 | Renamed extension, zero-byte, truncated signature, spoofed content-type, oversized filename, Arabic filename, HTTP-level duplicate, traversal, reserved name |
| L5 Large file | 2 | 20MB real upload, checksum + size verified, timed |
| L6 Security | 15 | 10 path-traversal payload variants + encoded traversal + rename-traversal + directory-mutation guard + static execution/extraction checks |
| L7 Regression | 1 | Previously-uploaded evidence remains listed |
| **Total** | **60/60 passed** | |

Combined with the full pre-existing suite (unchanged, all still
passing): **208/217 total across the whole project**, with the same 9
documented, pre-existing, unrelated `verify:viewer` fixture-path
failures as every prior phase.

---

## 16. Performance Findings

Measured in this sandboxed environment (single-instance Node process, no
GUI):

- Small file (few KB, e.g. `.txt`/`.json`/`.csv` fixtures): sub-10ms
  intake time (not separately timed — negligible relative to test-harness
  overhead).
- Medium file (real minimal Office-zip fixtures, tens of bytes to a few
  KB): same, negligible.
- Large file (20MB random bytes): **705ms** end-to-end (HTTP request →
  validate → checksum → temp-write → verify → atomic rename → HTTP
  response), measured via `scripts/evidence-intake-test.js` Level 5.

**No claim is made about behavior at the true 300MB ceiling** — a
300MB synthetic upload was not run in this sandbox to avoid an
excessively long test-suite run time; 20MB was chosen as a realistic
stand-in for "a large scanned PDF or short video clip," which is the
kind of file size this product's actual use case (school accreditation
evidence) is expected to see routinely. Extrapolating linearly from the
20MB measurement, a 300MB upload would be expected to take on the order
of ~10 seconds in an environment with comparable disk I/O — this is an
estimate, not a measurement, and is flagged as such.

**UI responsiveness during upload was not measured** — this sandbox has
no display server (same limitation documented in every prior phase), so
whether the current synchronous `express.raw()` body-buffering approach
causes a noticeable UI stall for very large files could not be observed
directly. This is flagged as a known gap in this phase's verification,
not asserted either way.

---

## 17. Security Test Results

All 15 Level-6 security checks passed:

- 10 path-traversal filename payloads (`../`, `../../`, `..\`, `..\..\`,
  bare absolute POSIX path, Windows drive-letter absolute path, UNC
  path, `....//` double-dot-slash, and two mixed-separator variants) —
  every one either rejected outright or safely collapsed to a plain
  basename-only filename that lands strictly inside the evidence root.
- 1 URL-encoded traversal payload (`%2e%2e%2f...`) — same result.
- 1 rename-endpoint traversal payload — confirmed the destination is
  neutralized to a safe basename, never escaping the indicator folder.
- 1 re-verification of the Phase 2 directory-mutation guard (delete/
  rename cannot target `.` to reach a structural folder) — still holds
  under Phase 3's changes.
- 2 static-analysis checks (no execution-capable API usage in the intake
  path; no archive-extraction library usage anywhere in
  `evidenceService.js`).

**Result: the final stored path remained inside the intended evidence
root in every single test, with zero exceptions.**

---

## 18. Known Limitations

- **Evidence identity remains filename-based**, by deliberate,
  documented choice (§6) — not a full evidence-ID/database model. A
  checksum is available per-upload but is not currently persisted as a
  queryable, permanent per-file record (it's returned in the HTTP
  response and referenced in the audit-log note only when a rename
  occurred, not stored as a standing "this file's known-good hash"
  ledger entry). A future phase could add a lightweight sidecar
  (`evidence-checksums.json` in the same style as the existing
  `store.json`) without needing a full database — flagged as a
  recommendation, not implemented here.
- **300MB ceiling not empirically tested** — only extrapolated from a
  20MB measurement (§16).
- **UI responsiveness under large uploads was not measured** — no
  display server available in this sandbox (§16). The existing upload
  code path is synchronous/blocking at the Express layer (the whole
  request body is buffered in memory before `classifyUpload` even runs)
  — this was already true before Phase 3 (documented in the Phase 0
  audit) and this phase did not change that architecture, per the
  brief's explicit "do not build a new upload interface... focus on
  reliable intake behavior" instruction. Whether this is a real,
  user-visible problem worth a streaming-upload redesign is a
  recommendation for a future phase, not something this phase attempted
  to fix or definitively rule in/out.
- **`MAX_FILENAME_LENGTH` (150 chars) does not guarantee the full path
  stays under Windows' classic 260-character `MAX_PATH`** on every
  possible combination of long install directory + long domain/standard/
  indicator folder names + a long filename — see
  `PHASE_2_STANDARDS_MANIFEST.md`'s "Existing Assumptions" for the
  folder-name-length context. A future phase could recommend enabling
  Windows long-path support at the electron-builder/NSIS level as a more
  complete fix; not attempted here (an installer-level change, out of
  this phase's file-intake scope).
- **The `resources/evidence-template/` packaging gap** (Phase 0 §5/§19)
  remains unchanged and unfixed — restated here only because it remains
  the single most consequential pre-existing issue in the project,
  unrelated to this phase's actual scope.

---

## 19. Future Viewer Integration

Nothing in this phase's changes requires any change to
`app/js/viewer.js` or any other viewer code — this was verified
explicitly (`git diff` against `app/js/viewer.js` and `app/index.html`
produces zero output for this phase, same as every prior phase). The
new "unknown but safe" and "archive" categories both already have a
defined `fallback: 'external-open'` behavior in `FileSupportPolicy`,
meaning the *existing* viewer's `renderUnsupportedOffice()`/
`renderFallback()` code paths (documented in Phase 0's audit §13)
already handle them correctly with zero additional viewer work — a file
in either of these new categories shows the same "open externally"
prompt any other no-preview file already shows. A future viewer phase
that wants to add real preview for any specific new category (e.g. a
particular unknown-but-common format a school turns out to use a lot)
can do so by adding one new `EXTENSIONS` entry with a real
`preview.engine`, without needing to touch this phase's intake logic at
all — the intake/preview separation this phase reinforces is exactly
what makes that possible.
