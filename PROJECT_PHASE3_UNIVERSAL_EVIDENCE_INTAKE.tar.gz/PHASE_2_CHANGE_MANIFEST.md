# PHASE 2 — Change Manifest

Working copy: `/home/claude/workspace/phase1-working-copy`
Starting commit (Phase 1 end state): `360e587` ("docs: add Phase 1 architecture report and change manifest")

---

## Added Files

### `server/services/standardsService.js`
- **What changed:** new module — a thin, explicitly-named facade for
  standards-structure concerns: `getFolderName()`, `resolveRoot()`,
  `verifyRootExists()`, `getStructureSummary()`,
  `computeIntegrityManifest()`, `compareIntegrityManifest()`.
- **Why it changed:** Phase 2's "Architectural Objective" calls for one
  clear place the application resolves/reasons about the immutable
  standards root, and for cryptographic integrity tooling that did not
  exist before this phase.
- **Why it belongs in Phase 2:** it is the direct implementation of this
  phase's stated deliverables (structure manifest generation, integrity
  baseline generation/comparison) — nothing here touches evidence
  *content*, viewers, licensing, or backup.
- **What behavior it affects:** none for existing functionality — it is
  purely additive; no existing route, service, or renderer file was made
  to depend on it except where explicitly noted below (the two guard
  additions reference its documentation, not its code).
- **How it was tested:** `scripts/standards-contract-test.js` (10/10,
  see below) exercises every exported function; the baseline-generation
  script (`scripts/generate-standards-baseline.js generate`) independently
  cross-checked against a manually-computed `sha256sum` of every file in
  the real standards folder — all 7 hashes matched exactly.

### `server/services/standardsIntegrityService` — *(not created; folded into `standardsService.js` instead)*
Noted here explicitly because a two-module split was considered and
rejected: Phase 2's own "Code Quality" section warns against "helper
files with unclear responsibility." A single `standardsService.js`
covering both structure-facade and integrity-manifest concerns kept the
module count minimal without mixing it into `evidenceService.js` (which
owns evidence *content* operations, a distinct concept per this phase's
"VERY IMPORTANT DISTINCTION" section).

### `scripts/generate-standards-baseline.js`
- **What changed:** new CLI tool (`generate`/`verify` subcommands) that
  loads `standardsService.js` under the same electron-mock harness pattern
  every other `scripts/*.js` test already uses, and either writes or
  compares an integrity manifest for a given directory.
- **Why it changed:** this is what generated
  `PHASE_2_STANDARDS_INTEGRITY_BASELINE.json` and what re-verified it
  after every subsequent change in this phase — the brief requires the
  baseline be generated "programmatically," not hand-constructed.
- **Why it belongs in Phase 2:** direct implementation of the "Create a
  Cryptographic Baseline" and "Integrity Regression Test" requirements.
- **What behavior it affects:** none — a standalone dev/ops tool, not
  imported by the application itself.
- **How it was tested:** run in `generate` mode against the real standards
  folder, output cross-checked against an independent `sha256sum` run
  (exact match on all 7 files); run in `verify` mode after every
  subsequent code change in this phase, always reporting
  `STRUCTURE IDENTICAL`.

### `scripts/standards-contract-test.js` (+ `"verify:standards"` npm script)
- **What changed:** new automated test suite, 10 tests, one per goal
  listed in the Phase 2 brief's "Testing" section (root resolves, root
  exists, hierarchy exists, folders exist, app can read structure,
  renderer has no direct fs access, path resolution works, missing root
  handled safely, no unexpected mutation occurs, integrity verification
  detects a changed file).
- **Why it changed:** the brief explicitly requires tests "around the
  immutable standards contract," listing these exact ten goals.
- **Why it belongs in Phase 2:** direct implementation of the "Testing"
  section; uses only the real, existing structure (never asserts a "new"
  structure), per the brief's explicit instruction.
- **What behavior it affects:** none — a test file, run manually via
  `npm run verify:standards`.
- **How it was tested:** the suite is itself the test; it was run
  repeatedly during development until all 10 passed, then included in
  every subsequent full-suite regression run in this phase (always
  10/10 after the initial pass).

### `PHASE_2_STANDARDS_MANIFEST.md`, `PHASE_2_STANDARDS_INTEGRITY_BASELINE.json`, `PHASE_2_CHANGE_MANIFEST.md`, `PHASE_2_REPORT.md`
Documentation/data deliverables required by the brief. The integrity
baseline JSON was generated programmatically (never hand-written) by
`scripts/generate-standards-baseline.js generate`, using
`standardsService.computeIntegrityManifest()`.

---

## Modified Files

### `server/services/evidenceService.js`
- **What changed:** `deleteEvidenceFile()` and `renameEvidenceFile()` each
  gained one additional check: after resolving the target path and
  confirming it exists, verify via `fs.lstatSync(...).isFile()` that the
  target is a regular file before mutating it. If it isn't, both functions
  now return `{ ok: false, reason: 'NOT_A_FILE' }` instead of proceeding.
- **Why it changed:** investigating this phase's "Read-Only Contract"
  section (identify unsafe mutation paths targeting the standards
  directory) surfaced a real, reproducible gap: a crafted `name`/`oldName`
  value of `"."` resolves — via `path.basename('.')` returning `'.'` — to
  the **indicator folder itself** (a structural directory, not an
  evidence file), which the existing containment check does not reject
  (the resolved path does equal the trusted directory). Verified in
  isolation (not against the real repo) that this reached
  `fs.unlinkSync()`/`fs.renameSync()` and threw an uncaught `EISDIR`/OS-
  dependent `EINVAL` rather than being cleanly rejected. See
  `PHASE_2_REPORT.md` §6 "Read-Only Contract" for the full investigation
  and reproduction steps.
- **Why it belongs in Phase 2:** this is exactly what the brief's
  "Read-Only Contract" section asks for — "Identify the unsafe mutation
  paths… Prevent accidental mutation where appropriate" — applied
  narrowly to the one gap actually found, not a general hardening pass.
- **What behavior it affects:** a new, previously-nonexistent/undefined
  behavior for an input (`"."` as a filename) that the application's own
  UI never sends — it only ever operates on real filenames returned by
  `GET /api/files/:code`'s own listing, which never contains `"."` or
  `".."` as an entry. No legitimate, UI-driven request is affected; the
  affected surface is only reachable by someone constructing a raw HTTP
  request by hand. This is a documented behavior change, not a
  side-effect.
- **How it was tested:** reproduced the pre-existing gap in an isolated
  `/tmp` sandbox (not the real repo) before making any change, to confirm
  it was real; after the fix, `scripts/standards-contract-test.js` test
  #9 exercises both functions against a scratch directory and asserts (a)
  the structural folder survives both attempts, (b) a real file in the
  same folder can still be deleted/renamed normally (the guard doesn't
  over-block). All pre-existing suites re-run afterward with zero
  regressions (`verify:server` 15/15, `verify:part2-remaining` 12/12 —
  the suite with the most rename/delete edge-case coverage — and all
  others unchanged).

### `server/routes/files.js`
- **What changed:** the `DELETE /api/file/:code/:name` and
  `PATCH /api/file/:code/rename` handlers each gained one additional
  `switch`/`if` branch mapping the new `NOT_A_FILE` result reason to the
  exact same HTTP status/response shape as the existing "not found" cases
  (`404` with the existing "الملف غير موجود" / "الملف الأصلي غير موجود"
  messages) — deliberately reusing the existing message rather than
  introducing new user-facing text, since from the API consumer's
  perspective both cases mean the same thing: "there's no such evidence
  file to act on."
- **Why it changed:** direct consequence of the `evidenceService.js`
  change above.
- **Why it belongs in Phase 2:** same as above.
- **What behavior it affects:** same as above — only reachable via a
  crafted request, never via the app's own UI.
- **How it was tested:** same suites as above (this file and
  `evidenceService.js` were changed and tested together as one logical
  unit).

### `package.json`
- **What changed:** one line added — `"verify:standards": "node
  scripts/standards-contract-test.js"` — alongside the project's existing
  `verify:*` scripts.
- **Why it changed:** registers the new Phase 2 test suite the same way
  every other test script in the project is registered.
- **Why it belongs in Phase 2:** trivial, direct consequence of adding
  the test file.
- **What behavior it affects:** none — adds a script entry only; no
  dependency was added, changed, or removed. `package-lock.json` is
  untouched (zero diff).
- **How it was tested:** ran `npm run verify:standards` directly to
  confirm the script entry resolves and executes correctly.

---

## Moved Files

None.

## Renamed Files

None.

## Deleted Files

None.

---

## Configuration Changes

None beyond the one `package.json` script-registration line above. No
path, no folder name, no evidence-root resolution logic, and no
environment variable behavior changed.

## Installer Changes

None. Re-inspected (per the brief's explicit "Installer" section)
`package.json`'s `build.extraResources` and `build/installer.nsh`:
both still reference `resources/evidence-template/`, which still does not
exist in the repository — this is the same gap Phase 0 documented and
this phase re-confirms, unchanged. No installer file was modified,
because doing so was not "necessary to guarantee the existing immutable
folder is included correctly" (per the brief's own conditional) — the
folder's *structure* is guaranteed by `ensureAllFolders()` running at
every app startup regardless of whether the seed template exists; the
missing template only affects whether pre-populated sample content ships,
which is a distinct, already-documented, out-of-scope issue (see
`PHASE_2_REPORT.md` §7 and §14).

## Test Changes

Two additions only (`scripts/standards-contract-test.js`,
`scripts/generate-standards-baseline.js`), described above. No existing
test file was modified, weakened, or deleted. All pre-existing tests
(126 across six suites, plus `verify:viewer`'s 10 passing / 9
pre-existing-failure split) run identically to their Phase 1 end-state
results.

---

## Summary Table

| Change | Files touched | Behavior change | Test evidence |
|---|---|---|---|
| Standards facade + integrity tooling | `standardsService.js` (new), `generate-standards-baseline.js` (new) | None (purely additive) | Cross-checked against independent `sha256sum`; used to generate/verify `PHASE_2_STANDARDS_INTEGRITY_BASELINE.json` |
| Read-only structural-mutation guard | `evidenceService.js`, `routes/files.js` | Yes, narrowly: a crafted `"."` filename is now cleanly rejected (404) instead of throwing an uncaught filesystem error | `verify:standards` test #9; full regression suite unchanged (126/126 pre-existing tests still pass) |
| New standards-contract test suite | `standards-contract-test.js` (new), `package.json` (+1 line) | None | Suite itself: 10/10 |

**Total files touched across Phase 2:** 3 modified
(`evidenceService.js`, `routes/files.js`, `package.json`), 6 created
(`standardsService.js`, `generate-standards-baseline.js`,
`standards-contract-test.js`, and the three Phase 2 Markdown/JSON
deliverables — `PHASE_2_REPORT.md` counted separately since it's written
last), 0 moved, 0 renamed, 0 deleted. The immutable standards directory
itself: **0 files/folders added, removed, renamed, or modified** —
verified via SHA-256 comparison before and after every step.
