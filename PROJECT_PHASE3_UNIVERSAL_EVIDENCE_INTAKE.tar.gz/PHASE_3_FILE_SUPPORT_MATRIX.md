# PHASE 3 — File Support Matrix

Generated directly from the live `app/js/file-support-policy.js` policy
data (not hand-transcribed) via `node -e "require('./app/js/file-support-policy.js')..."`,
so it reflects exactly what the running server enforces, not an aspirational
description. The **Preview** column reflects the CURRENT application (no
viewer changes were made in Phase 3), per the brief's explicit requirement.

---

## Known Extensions (42 entries, unchanged categories/preview from before Phase 3)

| Extension | Category | Upload | Store | Preview | External Open | Max Size |
|---|---|---|---|---|---|---|
| `.pdf` | pdf | YES | YES | YES (full) | n/a (previewed internally) | 100MB |
| `.docx` | word | YES | YES | YES (full) | n/a (previewed internally) | 25MB |
| `.doc` | word | YES | YES | NO | YES | 25MB |
| `.rtf` | word | YES | YES | NO | YES | 25MB |
| `.odt` | word | YES | YES | NO | YES | 25MB |
| `.xlsx` | excel | YES | YES | YES (full) | n/a (previewed internally) | 25MB |
| `.xls` | excel | YES | YES | YES (full) | n/a (previewed internally) | 25MB |
| `.xlsm` | excel | YES | YES | YES (full) | n/a (previewed internally) | 25MB |
| `.ods` | excel | YES | YES | NO | YES | 25MB |
| `.csv` | csv | YES | YES | YES (full) | n/a (previewed internally) | 25MB |
| `.pptx` | powerpoint | YES | YES | YES (**partial** — text + embedded images only) | n/a (previewed internally) | 100MB |
| `.ppt` | powerpoint | YES | YES | NO | YES | 100MB |
| `.odp` | powerpoint | YES | YES | NO | YES | 100MB |
| `.jpg` / `.jpeg` | image | YES | YES | YES (full) | n/a (previewed internally) | 25MB |
| `.png` | image | YES | YES | YES (full) | n/a (previewed internally) | 25MB |
| `.gif` | image | YES | YES | YES (full) | n/a (previewed internally) | 25MB |
| `.bmp` | image | YES | YES | YES (full) | n/a (previewed internally) | 25MB |
| `.webp` | image | YES | YES | YES (full) | n/a (previewed internally) | 25MB |
| `.svg` | image | YES | YES | YES (full) | n/a (previewed internally) | 5MB |
| `.mp4` / `.m4v` | video | YES | YES | YES (full) | n/a (previewed internally) | 200MB |
| `.webm` | video | YES | YES | YES (full) | n/a (previewed internally) | 200MB |
| `.mov` | video | YES | YES | YES (full) | n/a (previewed internally) | 200MB |
| `.mkv` | video | YES | YES | YES (full) | n/a (previewed internally) | 200MB |
| `.avi` | video | YES | YES | YES (full) | n/a (previewed internally) | 200MB |
| `.mp3` | audio | YES | YES | YES (full) | n/a (previewed internally) | 200MB |
| `.wav` | audio | YES | YES | YES (full) | n/a (previewed internally) | 200MB |
| `.m4a` | audio | YES | YES | YES (full) | n/a (previewed internally) | 200MB |
| `.ogg` | audio | YES | YES | YES (full) | n/a (previewed internally) | 200MB |
| `.aac` | audio | YES | YES | YES (full) | n/a (previewed internally) | 200MB |
| `.flac` | audio | YES | YES | YES (full) | n/a (previewed internally) | 200MB |
| `.txt` / `.md` / `.log` | text | YES | YES | YES (full) | n/a (previewed internally) | 10MB |
| `.json` / `.xml` | text | YES | YES | YES (full) | n/a (previewed internally) | 10MB |

## Archives (Phase 3: newly enabled for upload)

| Extension | Category | Upload | Store | Preview | External Open | Max Size | Notes |
|---|---|---|---|---|---|---|---|
| `.zip` | archive | **YES (new)** | YES | NO | YES | 300MB | Stored as opaque evidence. **Never automatically extracted or inspected.** |
| `.rar` | archive | **YES (new)** | YES | NO | YES | 300MB | Same as above. |
| `.7z` | archive | **YES (new)** | YES | NO | YES | 300MB | Same as above. |
| `.tar` | archive | **YES (new)** | YES | NO | YES | 300MB | Same as above. |
| `.gz` | archive | **YES (new)** | YES | NO | YES | 300MB | Same as above. |

Before Phase 3, all five were `upload.allowed: false` (Phase 0's audit
documented this as a deliberate pre-Phase-3 decision). Phase 3 reverses
that decision because the brief explicitly lists ZIP/RAR/7Z among the
required "universal intake" formats, and explicitly instructs that *if*
archives are accepted, they must never be auto-extracted — which is
exactly the policy implemented.

## Unknown-But-Safe (Phase 3: new open-ended category)

| Match | Category | Upload | Store | Preview | External Open | Max Size | Notes |
|---|---|---|---|---|---|---|---|
| Any extension **not** in the known list above **and not** on the dangerous deny-list below | other | **YES (new)** | YES | NO | YES | 50MB | The core of "universal file intake" — uploadability is no longer limited to formats the application anticipated in advance. |
| No extension at all (e.g. `README`) | other | **YES (new)** | YES | NO | YES | 50MB | Same bucket — an extensionless filename is not treated as invalid. |

## Dangerous — Always Rejected (Phase 3: new explicit deny-list, 36 extensions)

| Extensions | Category | Upload | Store | Notes |
|---|---|---|---|---|
| `exe`, `msi`, `bat`, `cmd`, `com`, `scr`, `pif`, `lnk` | — | **NO** | NO | Classic Windows executable/installer/shortcut formats |
| `ps1`, `ps1xml`, `psc1`, `psd1`, `psm1` | — | **NO** | NO | PowerShell script family |
| `vbs`, `vbe`, `js`, `jse`, `ws`, `wsf`, `wsh`, `hta` | — | **NO** | NO | Windows Script Host family |
| `jar`, `app`, `sh`, `bash` | — | **NO** | NO | Cross-platform executable/script formats |
| `dll`, `sys`, `drv` | — | **NO** | NO | Windows loadable modules/drivers |
| `cpl`, `gadget`, `msc`, `reg` | — | **NO** | NO | Windows control-panel/registry-modifying formats |
| `msix`, `appx`, `apk`, `dmg` | — | **NO** | NO | Platform installer/package formats |

Rejected via `reason: 'DANGEROUS_TYPE'`, HTTP 415, regardless of file
size or content — these are never even checked against a size or
signature rule, since the type itself is the disqualifying factor. Never
executed, inspected, or treated as code by this application under any
circumstance (grep-verified: no `child_process`/`eval`/`Function`/`vm`
usage anywhere in the intake path).

---

## Summary

- **42** explicitly-known extensions (10 categories), preview support
  unchanged from before Phase 3.
- **5** archive extensions newly accepted for upload (Phase 3), never
  auto-extracted, no preview.
- **Unbounded** additional extensions now acceptable as "unknown but
  safe" (Phase 3), capped at 50MB, no preview, external-open only.
- **36** extensions explicitly, permanently rejected regardless of
  content or size.

This table is regenerable at any time via:
```
node -e "console.log(JSON.stringify(require('./app/js/file-support-policy.js').EXTENSIONS, null, 2))"
```
