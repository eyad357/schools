# PHASE 3 — Change Manifest

Working copy: `/home/claude/workspace/phase1-working-copy`
Starting commit (Phase 2 end state): `0651b35` ("docs: add Phase 2 change manifest and final report")

Commits this phase:
- `55980c9` — `feat: universal file intake policy (Phase 3)`
- `2e56759` — `feat: atomic, checksummed, duplicate-safe evidence storage (Phase 3)`
- `262c553` — `test: add evidence-intake test suite covering all 7 Phase 3 test levels`
- `1b55374` — `fix: never leak raw filesystem error text to the client (Phase 3)`

---

## Files Added

### `scripts/evidence-intake-test.js` (+ `"verify:evidence-intake"` npm script)
- **What:** 60-check test suite covering all 7 levels the Phase 3 brief
  specified (unit, filesystem integration, real fixtures, malformed
  files, large file, security, regression).
- **Reason:** direct implementation of the brief's "Test Strategy"
  section.
- **Scope:** test-only, exercises intake code exclusively via throwaway
  scratch directories and a real HTTP server bound to a random port —
  never touches the real committed standards folder or its evidence.
- **Risk:** none — additive test file.
- **Validation:** the suite is itself the validation; 60/60 passing,
  re-run after every subsequent change in this phase.

### `PHASE_3_EVIDENCE_INTAKE_ARCHITECTURE.md`, `PHASE_3_FILE_SUPPORT_MATRIX.md`, `PHASE_3_CHANGE_MANIFEST.md`, `PHASE_3_REPORT.md`
Documentation deliverables required by the brief. The support matrix was
generated programmatically from live policy data, not hand-transcribed.

---

## Files Modified

### `app/js/file-support-policy.js`
- **What changed:** archives (`zip`/`rar`/`7z`/`tar`/`gz`) flipped from
  `upload.allowed:false` to `true` (capped at the new
  `MAX_UPLOAD_BYTES`=300MB). Added `MAX_UPLOAD_BYTES`,
  `DEFAULT_UNKNOWN_MAX_BYTES` (50MB), `DANGEROUS_EXTENSIONS` (36-entry
  deny-list), `WINDOWS_RESERVED_NAMES`, `RESERVED_CHARS_REGEX`,
  `MAX_FILENAME_LENGTH` (150), and `validateFilename()`. `classifyUpload()`
  rewritten to a three-tier decision (known / dangerous / unknown-safe)
  instead of allow-list-only, and to call `validateFilename()` +
  reject zero-byte input before the type/size checks run.
  `getPolicy()`/`isUploadAllowed()` refactored to share a new
  `resolveExt()` helper, and `isUploadAllowed()` updated to agree with
  `classifyUpload()`'s three-tier decision (previously it only consulted
  the `EXTENSIONS` table and would have disagreed about the new
  unknown-safe tier).
- **Reason:** direct implementation of the "Core Objective" (universal
  intake, uploadability separated from viewability), "Extension + MIME
  Handling," "File Size Validation," and "Filename Security" sections of
  the Phase 3 brief.
- **Risk:** Medium — this is a real policy change affecting what the
  server will and won't accept. Mitigated by: exhaustive test coverage
  (both the pre-existing `verify:file-support-policy` suite, updated
  where its old assertions tested the *previous* policy, and the new
  `verify:evidence-intake` suite); every decision documented with an
  explicit rationale in `PHASE_3_EVIDENCE_INTAKE_ARCHITECTURE.md`.
- **What behavior it affects:** archives now upload successfully where
  they previously received a 415; previously-unrecognized extensions now
  upload successfully (capped at 50MB) instead of receiving a 415;
  filenames with Windows-reserved names, disallowed characters, trailing
  dots/spaces, or excessive length are now rejected at upload time (400)
  where they previously would have been silently accepted by
  `classifyUpload` (though such a file would likely have caused problems
  on an actual Windows filesystem later — this closes that latent gap,
  it does not newly restrict anything that previously worked correctly).
  Zero-byte uploads are now rejected (400) where they previously
  succeeded.
- **How it was tested:** `verify:file-support-policy` 63/63 (7 assertions
  updated to reflect the new intentional policy, 3 new assertions added,
  none deleted or weakened — see below); `verify:evidence-intake` L1/L3/
  L4/L6 exercise this file directly and via full HTTP round-trips.

### `scripts/file-support-policy-test.js`
- **What changed:** the 7 assertions that tested the *previous*
  archives-blocked/unknown-rejected policy were updated to test the
  *new*, deliberate Phase 3 policy instead (archives allowed + no
  preview; unknown-but-safe allowed + no preview; dangerous deny-list
  still blocked). No assertion was deleted — each old expectation was
  replaced with the corresponding new, correct expectation for the
  behavior this phase intentionally changed.
- **Reason:** the old assertions encoded the pre-Phase-3 policy as
  "correct" — leaving them unchanged would have made a passing test
  suite lie about what the server now actually does.
- **Risk:** Low — test-only change.
- **Validation:** `verify:file-support-policy` 63/63 (60 unchanged
  assertions + 3 new/updated ones, all passing).

### `server/services/evidenceService.js`
- **What changed:** `writeEvidenceFile(dir, filename, body)` rewritten
  (see `PHASE_3_EVIDENCE_INTAKE_ARCHITECTURE.md` §5 for the full
  before/after) to: generate a non-conflicting filename before writing
  (new `generateNonConflictingName()` export), compute a SHA-256 of the
  content, write to a same-directory hidden temp file, verify the
  written size, and atomically `fs.renameSync()` into place, with
  best-effort temp-file cleanup on any failure. Returns
  `{ destPath, filename, size, sha256 }` instead of the previous bare
  `destPath` string. `renameEvidenceFile()` updated to call the new
  shared `FileSupportPolicy.validateFilename()` instead of its own
  inline `INVALID_NAME`/`INVALID_CHARS` checks (now also catches
  Windows reserved device names and trailing dot/space on rename, which
  it did not before).
- **Reason:** direct implementation of the brief's "Storage
  Architecture," "Atomic File Storage," "Duplicate Handling," and
  "Checksum / Integrity" sections; closes a real silent-overwrite gap
  found during this phase's own investigation (not carried over from a
  prior phase's findings).
- **Risk:** Medium-High — this is the core storage-write path; a mistake
  here could corrupt or lose evidence. Mitigated by: the atomic
  temp-file-then-rename pattern (same pattern already used elsewhere in
  this codebase, by `server/store/store.js`, for its own writes — not a
  novel approach); explicit size-verification before the rename step;
  `verify:evidence-intake` L2's dedicated filesystem-integration checks
  (no leftover temp files, duplicate-no-overwrite verified by reading
  both files back and comparing content, failure-path cleanup); the full
  pre-existing regression suite re-run and confirmed unchanged.
- **What behavior it affects:** uploading a file with a name that
  already exists in that indicator's folder no longer overwrites the
  existing file — it is now stored under an auto-generated
  disambiguated name instead, and the HTTP response reports the actual
  stored name. This is a deliberate, documented behavior change (closing
  a data-loss bug), not a regression.
- **How it was tested:** `verify:evidence-intake` L1 (unit-level
  `generateNonConflictingName` check), L2 (filesystem-integration
  duplicate-no-overwrite + no-leftover-temp-file + EACCES-classification
  checks), L3 (13 real-fixture end-to-end checksums), L4 (HTTP-level
  duplicate check), L5 (20MB large-file checksum/size verification);
  `verify:part2-remaining` 12/12 (existing rename-endpoint suite,
  unaffected since `renameEvidenceFile`'s externally-observable behavior
  for already-valid names is unchanged); standards folder sha256 hashes
  unchanged throughout.

### `server/routes/files.js`
- **What changed:** raw-body Express size limit now derived from
  `FileSupportPolicy.MAX_UPLOAD_BYTES` instead of its own hardcoded
  `'200mb'` literal. Upload handler updated to consume the new
  `writeEvidenceFile()` return shape (`{filename, size, sha256}`) and
  include those fields plus `originalFilename` in the JSON response;
  audit-log entry now notes when an upload was auto-renamed. Rename's
  error-mapping `switch` extended with three new cases
  (`NAME_TOO_LONG`, `TRAILING_DOT_OR_SPACE`, `RESERVED_NAME`). New
  `classifyStorageError(err, context)` helper maps Node `fs` error codes
  to structured, user-safe reason codes and messages instead of echoing
  `err.message` — used in both the upload and rename catch blocks;
  raw error detail is now logged server-side via the existing
  `electron-log`-based logger (newly imported into this file) rather
  than only surfacing in the HTTP response.
- **Reason:** direct consequence of the `evidenceService.js` and
  `file-support-policy.js` changes above, plus direct implementation of
  the brief's "Error Handling" section ("Do NOT expose raw stack
  traces... absolute machine paths").
- **Risk:** Low-Medium — response-shape changes are additive (new
  fields, existing fields unchanged) except for the storage-error path,
  where the response body's `error` text changes from a raw Node
  message to a structured Arabic message. No client code in this
  repository parses that specific error-path text (`app/js/uploader.js`
  displays whatever `error` string it receives generically), so this is
  a safe change; confirmed via `git diff` that `app/js/uploader.js` was
  not touched.
- **What behavior it affects:** upload responses now include `size`,
  `sha256`, and `originalFilename`; storage-error (500) response bodies
  now contain a structured, safe message instead of a raw filesystem
  error string. Both are additive/safety improvements, not breaking
  changes to any existing successful-path contract.
- **How it was tested:** `verify:server` 15/15, `verify:part2` 11/11,
  `verify:part2-remaining` 12/12, `verify:evidence-intake`'s new EACCES
  classification check (L2) and every L3/L4/L5 check that reads the
  upload response body.

### `package.json`
- **What changed:** one line added —
  `"verify:evidence-intake": "node scripts/evidence-intake-test.js"`.
- **Reason:** registers the new Phase 3 test suite alongside the
  project's existing `verify:*` scripts.
- **Risk:** none.
- **Validation:** ran the script directly.

---

## Files Moved

None.

## Files Deleted

None.

## Configuration Changed

- The single raw-upload size ceiling moved from a hardcoded `'200mb'`
  string in `server/routes/files.js` to the new
  `FileSupportPolicy.MAX_UPLOAD_BYTES` constant (300MB), consumed by
  reference rather than duplicated. This is the "one clear configuration
  source" for size limits the brief's "File Size Validation" section
  asked for. No other size-limit values were centralized outside
  `file-support-policy.js`, which was already the single source for
  per-category limits before this phase (Phase 0 confirmed this).

## Dependencies Added or Changed

**None.** `package.json`'s `dependencies`/`devDependencies` and
`package-lock.json` are both byte-identical to the Phase 2 end state
(confirmed via `git diff` — zero output for `package-lock.json`; the one
`package.json` diff is the single added npm-script line above, not a
dependency change). All new logic (checksum via Node's built-in
`crypto` module, atomic writes via Node's built-in `fs`) uses only
standard-library APIs already used elsewhere in this codebase — no new
package was needed or added.

---

## Summary Table

| Change | Files touched | Behavior change | Test evidence |
|---|---|---|---|
| Universal intake policy (archives + unknown-safe + dangerous deny-list + filename validation) | `file-support-policy.js`, `file-support-policy-test.js` | Yes, deliberate and documented | `verify:file-support-policy` 63/63 |
| Atomic, checksummed, duplicate-safe storage | `evidenceService.js` | Yes, closes a real data-loss bug | `verify:evidence-intake` L1/L2/L3/L4/L5; `verify:part2-remaining` 12/12 |
| Structured, safe error responses | `routes/files.js` | Yes, closes a real info-leak gap | `verify:evidence-intake` L2 EACCES check |
| New intake test suite | `evidence-intake-test.js`, `package.json` | None (test-only) | 60/60 |

**Total files touched across Phase 3:** 5 modified
(`file-support-policy.js`, `file-support-policy-test.js`,
`evidenceService.js`, `routes/files.js`, `package.json`), 5 created
(1 test script + 4 documentation deliverables — `PHASE_3_REPORT.md`
counted separately as it's written last), 0 moved, 0 renamed, 0
deleted. No viewer, UI, licensing, backup, or installer file was
touched (confirmed via `git diff --stat` against each). The immutable
standards directory: 0 changes — verified via SHA-256 comparison before
and after every commit in this phase.
