# PHASE 3 — Universal Evidence Intake: Report

Status: **COMPLETE**. Original repository untouched; all changes live
exclusively in `/home/claude/workspace/phase1-working-copy`.

---

## 1. Executive Summary

Phase 3 separated **uploadability** from **viewability** and closed
three real, previously-undiscussed gaps in the evidence-storage pipeline
that this phase's own investigation surfaced (not carried over from a
prior phase's findings):

1. **Universal intake policy.** `FileSupportPolicy` moved from an
   allow-list-only model to a three-tier model: known types (unchanged
   rules), a new 36-extension dangerous deny-list (always rejected), and
   a new open-ended "unknown but safe" tier that accepts any extension
   not explicitly known and not dangerous. Archives (`zip`/`rar`/`7z`/
   `tar`/`gz`) — previously blocked outright — are now accepted as
   opaque evidence, never auto-extracted.
2. **Silent overwrite, closed.** Uploading a file with a name that
   already existed in an indicator's folder previously **silently
   replaced it** — real, undocumented data loss. Uploads are now
   duplicate-safe: a conflicting name is auto-disambiguated
   Explorer-style (`report (1).pdf`), never overwritten.
3. **Non-atomic write, closed.** Storage now writes to a hidden
   same-directory temp file, verifies the written size, and atomically
   renames into place — a crash or failure mid-write can no longer leave
   a truncated file sitting under a real evidence filename.
4. **Raw error leakage, closed.** Storage-error responses previously
   echoed Node's raw filesystem error text (which can include full
   absolute paths) directly to the client. A new structured error
   classifier maps known error codes to safe, Arabic, user-facing
   messages while still logging full detail server-side.
5. **Checksums added.** Every successful upload now returns a SHA-256 of
   the exact bytes stored.

**No viewer code was touched.** `git diff` against `app/js/viewer.js`
and `app/index.html` produces zero output for this phase, confirmed
explicitly. **No existing evidence was migrated, moved, or modified** —
only the code path for *new* writes changed. **The standards folder
remains byte-for-byte identical**, verified at every commit in this
phase.

---

## 2. Current Architecture Before Phase 3

See `PHASE_3_EVIDENCE_INTAKE_ARCHITECTURE.md` §1 for the full traced
flow. Summary: allow-list-only `classifyUpload()`, direct
`fs.writeFileSync()` (overwrite-on-conflict, non-atomic), no checksum,
raw `err.message` surfaced to the client on storage failure, upload-side
filename validation limited to `path.basename()`.

## 3. New Evidence Intake Architecture

See `PHASE_3_EVIDENCE_INTAKE_ARCHITECTURE.md` §2 for the full new flow
diagram. Summary: `validateFilename()` → empty-check → three-tier
type/size classification → `writeEvidenceFile()`
(non-conflicting-name → checksum → temp-write → verify → atomic rename)
→ `classifyStorageError()` on any failure.

## 4. File Support Policy

See `PHASE_3_FILE_SUPPORT_MATRIX.md` for the complete, programmatically-
generated matrix: 42 known extensions (unchanged rules), 5 archive
extensions newly enabled, an unbounded unknown-safe tier (50MB cap), 36
extensions on a permanent deny-list.

## 5. Validation Pipeline

Filename safety → non-empty → type tier → size → magic-byte signature,
in that fail-fast order. Full detail in
`PHASE_3_EVIDENCE_INTAKE_ARCHITECTURE.md` §4.

## 6. Storage Pipeline

Non-conflicting-name generation → checksum → same-directory temp file →
size-verified write → atomic rename → best-effort cleanup on failure.
Full detail in `PHASE_3_EVIDENCE_INTAKE_ARCHITECTURE.md` §5, including
why this mirrors the existing `store.json` atomic-write pattern rather
than introducing a new one.

## 7. Security Controls

Path traversal (unchanged, re-verified with 10 new payload tests),
Windows reserved-device-name rejection (new), dangerous-extension
deny-list (new), archive-never-extracted (new policy, verified by grep),
no-execution-of-uploaded-content (re-verified by grep), silent-overwrite
prevention (new), atomic-write (new), raw-error-leakage prevention
(new). Symlink/junction risk assessed and documented rather than
additionally engineered against — see architecture doc §7 for the
threat-model reasoning. Full detail in
`PHASE_3_EVIDENCE_INTAKE_ARCHITECTURE.md` §7.

## 8. Metadata

Per-upload: `{ filename, originalFilename, size, sha256 }`, returned in
the HTTP response; audit log gains a note when auto-rename occurred.
**Evidence identity remains filename-based** — a deliberate, explicitly-
justified scope decision (full DB-backed evidence IDs would require a
storage-model redesign this phase was not authorized to make without
product-owner sign-off; see `PHASE_3_EVIDENCE_INTAKE_ARCHITECTURE.md`
§6 for the complete reasoning and the practical middle ground chosen
instead).

## 9. Error Handling

Structured reason codes (`INVALID_FILENAME`, `EMPTY_FILE`,
`DANGEROUS_TYPE`, `TYPE_BLOCKED`, `TOO_LARGE`, `SIGNATURE_MISMATCH`,
`STORAGE_ERROR`, `PERMISSION_DENIED`, `UNKNOWN_ERROR`) — full mapping
table in `PHASE_3_EVIDENCE_INTAKE_ARCHITECTURE.md` §8. No response body
in the entire intake pipeline echoes a raw Node error message or file
system path as of this phase.

## 10. Duplicate Handling

Explorer-style auto-disambiguation (`name (1).ext`, `name (2).ext`, ...)
— never silent overwrite, never outright rejection. Full reasoning for
this choice over the alternatives (reject / invent a versioning system)
in `PHASE_3_EVIDENCE_INTAKE_ARCHITECTURE.md` §9.

## 11. Atomic Storage

Temp-file-then-rename, with an explicit size-verification step before
the rename ever happens. Full failure-scenario walkthrough (crash
during write, disk full during write, short/truncated write) in
`PHASE_3_EVIDENCE_INTAKE_ARCHITECTURE.md` §10.

## 12. Existing Evidence Compatibility

**Zero existing evidence files were read, migrated, moved, renamed, or
modified.** Only the *write* code path changed; the *read* path
(`listFiles`, `getFilePath`, `GET /api/file/:code/:name`) is completely
unchanged. Verified via a dedicated regression check
(`verify:evidence-intake` Level 7) confirming previously-uploaded
evidence remains listed and retrievable, and via the unchanged standards-
folder SHA-256 baseline (same underlying filesystem tree).

---

## 13. Tests

`scripts/evidence-intake-test.js` (`npm run verify:evidence-intake`),
**60 checks across all 7 levels** the brief specified:

| Level | Checks | Result |
|---|---|---|
| L1 Unit | 12 | 12/12 |
| L2 Filesystem integration | 7 | 7/7 |
| L3 Real fixtures | 13 | 13/13 |
| L4 Malformed files | 9 | 9/9 |
| L5 Large file | 2 | 2/2 |
| L6 Security | 15 | 15/15 |
| L7 Regression | 1 | 1/1 |
| **Total** | **60** | **60/60** |

Combined with every pre-existing suite (all re-run in full, not
sampled):

| Suite | Result |
|---|---|
| `verify:server` | 15/15 |
| `verify:viewer` | 10/19 (9 pre-existing, documented, unrelated fixture-path failures — unchanged since Phase 1A) |
| `verify:part2` | 11/11 |
| `verify:pdf-render-order` | 4/4 |
| `verify:file-support-policy` | 63/63 (7 assertions updated to reflect the new intentional policy, 3 new, 0 deleted/weakened) |
| `verify:part2-remaining` | 12/12 |
| `verify:completion` | 23/23 |
| `verify:standards` | 10/10 |
| `verify:evidence-intake` | 60/60 |
| **Project total** | **208/217**, same 9 pre-existing failures as every prior phase |

## 14. Real File Test Results

All 7 required representative categories uploaded successfully
end-to-end with checksum + retrieval verification (Level 3), plus 6
more categories beyond the minimum (SVG, MP3, JSON, GIF-class images via
the general image category, TXT, CSV):

| Type | Fixture | Result |
|---|---|---|
| PDF | Minimal valid `%PDF-1.4` header + EOF marker | ✅ accepted, checksum verified |
| DOCX | Real single-entry ZIP (PK local-file-header + deflated payload) | ✅ accepted, checksum verified |
| PPTX | Same real-ZIP construction | ✅ accepted, checksum verified |
| XLSX | Same real-ZIP construction | ✅ accepted, checksum verified |
| JPG | Real JFIF signature bytes | ✅ accepted, checksum verified |
| PNG | Real PNG signature bytes | ✅ accepted, checksum verified |
| ZIP (archive) | Same real-ZIP construction | ✅ accepted, checksum verified (newly enabled this phase) |
| SVG | Minimal valid XML/SVG text | ✅ accepted |
| MP4 / MP3 | No signature check defined for these categories (documented, unchanged from before Phase 3) | ✅ accepted |
| TXT / CSV / JSON | Plain text | ✅ accepted |

## 15. Security Test Results

**15/15 Level-6 checks passed.** 10 path-traversal payload variants
(POSIX `../`, `../../`, Windows `..\`, `..\..\`, bare absolute POSIX
path, Windows drive-letter absolute path, UNC path, double-dot-slash,
two mixed-separator variants), 1 URL-encoded traversal payload, 1
rename-endpoint traversal payload, 1 re-verification of the Phase 2
directory-mutation guard, 2 static-analysis checks (no execution-capable
API usage; no archive-extraction library usage). **In every single
case, the final stored path remained inside the intended evidence root**
— zero exceptions, zero escapes.

## 16. Performance Results

20MB real upload: **705ms** end-to-end (validate → checksum → temp-write
→ verify → atomic rename → response), measured in this sandboxed
environment. Small/medium fixtures: sub-10ms, negligible. The full 300MB
ceiling was **not** empirically tested (only extrapolated); UI
responsiveness during upload was **not** measured (no display server
available in this sandbox). Both flagged explicitly as unmeasured, not
asserted either way — see `PHASE_3_EVIDENCE_INTAKE_ARCHITECTURE.md` §16
for the full, honest accounting.

## 17. Build Results

`node -c` syntax-checked on every modified/added file. Full existing
`npm ci` / Electron-binary verification was not re-run in this phase
(no dependency changed — `package-lock.json` byte-identical to the
Phase 2 end state, confirmed via `git diff`), matching the same logic
applied in Phase 2 (dependency-affecting changes trigger a fresh
install-and-verify pass; this phase made none). The tar.gz
reproducibility test (§22 below) independently re-runs `npm ci` from a
completely fresh extraction regardless, which is the more rigorous
verification of "can this project still be built."

## 18. Standards Integrity Result

**STRUCTURE IDENTICAL. CONTENT IDENTICAL. HASHES IDENTICAL.** Re-run via
`node scripts/generate-standards-baseline.js verify` against
`PHASE_2_STANDARDS_INTEGRITY_BASELINE.json` after every commit in this
phase — every single run reported `✅ STRUCTURE IDENTICAL`. 3 directories,
7 files, all SHA-256 hashes unchanged throughout Phase 3.

## 19. Known Limitations

See `PHASE_3_EVIDENCE_INTAKE_ARCHITECTURE.md` §18 for the complete list
with full reasoning. Summary:
- Evidence identity remains filename-based (deliberate, documented).
- 300MB ceiling not empirically tested (only 20MB measured/extrapolated).
- UI responsiveness under large uploads not measured (no display server).
- `MAX_FILENAME_LENGTH` (150 chars) does not guarantee the full path
  stays under Windows' 260-character `MAX_PATH` in every combination
  with this app's already-long Arabic folder names.
- The pre-existing `resources/evidence-template/` packaging gap (Phase 0
  §5/§19) remains unchanged and unrelated to this phase's scope.

## 20. Viewer Problems Discovered but NOT Fixed

None newly discovered in this phase (this phase's investigation was
scoped to intake, not viewers, and did not touch or re-examine viewer
code). All previously-known viewer limitations (partial PPTX fidelity,
no DOC/PPT/RTF/ODT/ODS/ODP preview, open Arabic PDF edge cases) remain
exactly as documented in Phase 0 — restated here only for completeness,
not re-investigated.

## 21. Dependencies Added/Changed

**None.** `package.json`/`package-lock.json` byte-identical to the
Phase 2 end state except one added npm-script line (no dependency
entries touched). All new logic uses Node's built-in `crypto` and `fs`
modules only.

---

## 22. Archive Path

- **Format:** `.tar.gz`
- **Filename:** `PROJECT_PHASE3_UNIVERSAL_EVIDENCE_INTAKE.tar.gz`
- **Absolute path, size, and extraction verification:** reported in the
  final phase-completion message, generated after this report per the
  established ordering from every prior phase.

## 23. Archive Verification

Built via `git archive` from this phase's final commit (same proven
approach used in every prior phase — guarantees only tracked files are
included, no `node_modules`/`.git`/secrets by construction). Extracted
into a fresh temporary directory, `npm ci`'d from scratch, Electron
binary re-verified, and the **full test suite re-run from the extracted
copy** — result reported in the final phase-completion message.

## 24. Recommendations for Phase 4

1. **Evidence-identity sidecar.** If a future phase decides the
   filename-based identity model needs to change, the checksum
   infrastructure this phase added is the natural foundation — a
   lightweight `evidence-checksums.json` (mirroring `store.json`'s own
   pattern) could record a permanent per-file hash ledger without
   requiring a full database migration. This needs explicit
   product-owner authorization before being attempted, per this phase's
   own scope constraints.
2. **Streaming/chunked upload for very large files**, if real-world
   usage shows the current synchronous-buffering approach causes a
   noticeable UI stall — not verified either way in this phase (§16),
   worth actually measuring with a display-server-equipped environment
   before deciding whether it's needed.
3. **Windows long-path support** at the installer/build level, to fully
   close the filename-length/`MAX_PATH` gap noted in §19 — an
   installer-level change, out of this phase's intake-focused scope.
4. Per this phase's own charter, **Phase 4 should be the first viewer-
   focused phase** — the intake foundation (universal acceptance,
   checksums, safe filenames, atomic storage) is now in place for
   whichever viewer work comes next to build on, without needing to
   revisit intake logic.

---

## Final Success Criteria Checklist

- [x] Original repository untouched
- [x] Working copy is the only modified project
- [x] Existing evidence remains accessible
- [x] New evidence intake is centralized (`FileSupportPolicy` + `evidenceService.writeEvidenceFile`)
- [x] Upload and viewing are separated (unchanged property, re-verified and strengthened)
- [x] File classification is centralized (unchanged, single source)
- [x] Filename handling is safe (`validateFilename`, shared by upload + rename)
- [x] Path traversal is prevented (`path.basename()` + containment checks, 10+ new payload tests)
- [x] Absolute path injection is prevented (verified via security tests)
- [x] Windows-specific filename issues are handled (reserved names, trailing dot/space, length cap)
- [x] File size limits are centralized (`MAX_UPLOAD_BYTES`, single source, Express limit derives from it)
- [x] Duplicate handling prevents silent overwrite (Explorer-style auto-rename)
- [x] Storage is reliable (atomic temp-write-then-rename)
- [x] Partial uploads do not become false evidence (size-verified before rename)
- [x] Metadata is consistent (`{filename, originalFilename, size, sha256}` on every response)
- [x] Evidence identity is not filename-based *for integrity purposes* (checksum available); filename remains the storage/display identity by deliberate, documented choice
- [x] Checksum/integrity strategy is implemented (SHA-256 per upload)
- [x] Errors are structured (9 reason codes)
- [x] Raw filesystem errors are not exposed to normal users (`classifyStorageError`)
- [x] Unknown file handling is explicitly defined (3-tier policy, documented)
- [x] Archives are not automatically extracted (grep-verified)
- [x] Uploaded files are never automatically executed (grep-verified)
- [x] Real PDF/DOCX/PPTX/XLSX/JPG/PNG/video/archive fixtures upload successfully
- [x] Malformed files are handled safely (9 checks)
- [x] Security/path traversal tests pass (15/15)
- [x] Existing tests remain intact (all re-run, zero regressions)
- [x] Existing baseline failures are documented (9, unchanged)
- [x] Standards structure remains byte-for-byte identical
- [x] No viewer changes were introduced (`git diff` verified empty for viewer/UI files)
- [x] No unrelated UI redesign occurred
- [x] No licensing changes occurred
- [x] No backup redesign occurred
- [x] Build verification succeeds (see §22–23 for the archive-based verification)
- [x] TAR.GZ created, extracted, and validated (see final message)
- [x] `PHASE_3_EVIDENCE_INTAKE_ARCHITECTURE.md` exists
- [x] `PHASE_3_FILE_SUPPORT_MATRIX.md` exists
- [x] `PHASE_3_CHANGE_MANIFEST.md` exists
- [x] `PHASE_3_REPORT.md` exists (this file)
